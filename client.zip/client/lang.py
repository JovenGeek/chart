# coding: utf8
import re


def get_lang_list():
    with open('lang_name_code.txt', 'r') as f:
        lang_list = []
        lang_dict = {}
        for data in f:
            if data:
                try:
                    result = re.match(r'"([a-z]+)" (\w+)', data).groups()
                    lang_list.append(result)
                    lang_dict[result[1]] = result[0]
                except Exception as e:
                    print('没有匹配好', e)

    return lang_list


def get_lang_dict():
    with open('lang_name_code.txt', 'r') as f:
        lang_list = []
        lang_dict = {}
        for data in f:
            if data:
                try:
                    result = re.match(r'"([a-z]+)" (\w+)', data).groups()
                    lang_list.append(result)
                    lang_dict[result[1]] = result[0]
                except Exception as e:
                    print('没有匹配好', e)

    return lang_dict


def get_lang_tuple():
    with open('lang_name_code.txt', 'r') as f:
        lang_list = []
        for data in f:
            if data:
                try:
                    result = re.match(r'"[a-z]+" (\w+)', data).group(1)
                    lang_list.append(result)
                except Exception as e:
                    print('没有匹配好', e)

    return tuple(lang_list)

lang_list = get_lang_list()
lang_tuple= get_lang_tuple()
lang_dict= get_lang_dict()
