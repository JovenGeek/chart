# coding: utf8
import tkinter as tk
#  from tkinter.messagebox import *
from socket import *
import sys
import re
import random
from tkinter import messagebox as mb
import os
import threading
import time
from multiprocessing import Process, Queue
from tkinter import ttk
import weather
import translate
import lang
import signal

if len(sys.argv) != 3:
        print('请输入addr')

# q = Queue(1)

class UserText():

    def __init__(self, user):
        self.user = user
        self.text = []

    def __repr__(self):
        return repr(self.user)

    def __getitem__(self, index):
        return self.user[index]

    def insert(self, tp):
        self.text.append(tp)


class GroupText():

    def __init__(self, group):
        self.group = group
        self.text = []

    def __repr__(self):
        return repr(self.group)

    def __getitem__(self, index):
        return self.group[index]

    def insert(self, tp):
        self.text.append(tp)

class Root(tk.Tk):

    """docstring for Root"""
    def __init__(self):
        super(Root, self).__init__()
        self.s = socket(AF_INET, SOCK_DGRAM)
        self.s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        signal.signal(signal.SIGCHLD, signal.SIG_IGN)
        try:
            self.ADDR = (sys.argv[1], int(sys.argv[2]))
        except Exception as e:
            print('错误:', e)
            os._exit(0)
        self.withdraw()
        th = threading.Thread(target=self.message_recv)
        print('h')
        th.setDaemon(True)
        th.start()
        self.anchor('center')
        self.create_toplevel()
        self.login_toplevel()
        self.mainloop()
        # th.join()

    def create_toplevel(self):
        self.toplevel = tk.Toplevel()
        # self.toplevel.resizable(width=True, height=True)

    # 设置登录界面
    def login_toplevel(self):
        self.user_id = tk.StringVar()
        self.password = tk.StringVar()
        self.toplevel.destroy()
        self.toplevel = tk.Toplevel()
        self.toplevel.wm_protocol("WM_DELETE_WINDOW", self.leave)
        self.toplevel.title("登录")
        self.img = tk.PhotoImage(file='swp.gif')
        self.tag = tk.Label(self.toplevel, image=self.img)
        self.tag.config(image=self.img)
        self.tag.image = self.img
        self.tag.grid(row=0, rowspan=5, padx=10)
        tk.Label(self.toplevel).grid(row=0)
        tk.Label(self.toplevel, text='账  户:').grid(row=1, column=1, pady=10, padx=10)
        tk.Entry(self.toplevel, textvariable=self.user_id, validate='focusout', vcmd=self.id_check, invcmd=self.id_error,
                 width=25, highlightthickness=0).grid(row=1, column=2, columnspan=4, sticky=tk.W)
        tk.Label(self.toplevel, text='由12位数字组成', fg='grey').grid(row=1, column=6, stick=tk.W, padx=10)
        tk.Label(self.toplevel, text='密  码:').grid(row=2, column=1, pady=10)
        tk.Entry(self.toplevel, textvariable=self.password, validate='focusout', vcmd=self.passwd_check, invcmd=self.passwd_error, width=25,
                 show='*', highlightthickness=0).grid(row=2, column=2, columnspan=4, sticky=tk.W)
        tk.Label(self.toplevel, text='由6-16位大小写字母和数字组成', fg='grey').grid(row=2, column=6, stick=tk.W, padx=10)
        self.login_register_button = tk.Button(self.toplevel, text='注册', command=self.register_toplevel, bd=0, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        # self.login_register_button.after(1, func=lambda: self.login_register_button.config(relief = tk.FLAT))
        self.login_register_button.grid(row=3, column=2, columnspan=2, pady=10, padx=10)
        self.login_button = tk.Button(self.toplevel, text='登录', command=self.login, relief=tk.FLAT, bd=0, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        self.login_button.grid(row=3, column=4, columnspan=2, pady=10, padx=10)
        self.w = self.toplevel.winfo_width()
        self.h = self.toplevel.winfo_height()
        sw = self.toplevel.winfo_screenwidth()
        sh = self.toplevel.winfo_screenheight()
        self.toplevel.anchor('center')
        self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.toplevel.geometry(self.alignstr)

    def login(self):
        if not (self.id_check() and self.passwd_check()):
            mb.showerror('登录失败', '输入错误!         ')
            return
        self.msg = 'U {} {} L'.format(self.user_id.get(), self.password.get()).encode()
        self.s.sendto(self.msg, self.ADDR)

    def main_user_interface(self, data):
        self.toplevel.destroy()
        self.toplevel = tk.Toplevel()
        title = '{}({})'.format(self.user_name, self.user_id.get())
        self.toplevel.wm_protocol("WM_DELETE_WINDOW", self.login_out)
        self.toplevel.title(title)
        sw = self.toplevel.winfo_screenwidth()
        sh = self.toplevel.winfo_screenheight()
        self.toplevel.anchor('center')
        self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.toplevel.geometry(self.alignstr)
        # 获取好友列表和群列表, 元素为元组(id, name)以名字的顺序排列

        self.groups = []
        for group in re.findall(r"G([0-9]{10}) (\w{5,20}) ([0-9]{12})", data):
            self.groups.append(GroupText(group=group))
        print(self.groups, data)
        self.my_groups = tk.Listbox(self, selectmode = tk.BROWSE, height=18, bg='#EEEAE8', highlightthickness=0, bd=0)
        self.groups.sort(key=lambda x: x[1])
        self.talk_to = tk.StringVar()
        self.talk_to.set('')
        self.list_frame = None
        self.selected_friend = '系统'
        self.selected_group = '系统'
        self.text_frame = tk.Frame(self.toplevel, width=60)
        self.text_frame.propagate(0) 
        self.text_frame.grid(row=1, rowspan=2, column=2, columnspan=4)

        self.text_sb_frame = tk.Frame(self.text_frame, width=60)
        self.text_sb_frame.propagate(0) 
        self.text_sb_frame.grid(row=0, rowspan=3, column=0, sticky=tk.N)

        self.friends = []
        for friend in re.findall(r"U([0-9]{12}) (\w{5,20})", data):
            self.friends.append(UserText(user=friend))

        self.friends_button = tk.Button(self.toplevel, text='好 友', command=self.friends_list, state='disabled', bd=0, relief=tk.FLAT, cursor='hand2')
        self.friends_button.grid(row=0, column=0, sticky=tk.N + tk.S + tk.W + tk.E)
        self.groups_button = tk.Button(self.toplevel, text='群 聊', command=self.groups_list, bd=0, relief=tk.FLAT, cursor='hand2')
        self.groups_button.grid(row=0, column=1, sticky=tk.N + tk.S + tk.W + tk.E)
        self.delete_button_text = tk.StringVar()
        self.more_info_text = tk.StringVar()
        self.speed_of_progress = tk.StringVar()
        self.already_send_size = 0
        # self.speed_of_down_load_update = tk.StringVar()
        # self.already_down_load_size = 0


        self.title_frame = tk.Frame(self.toplevel)
        self.title_frame.grid(row=0, column=2, columnspan=3)

        # self.delete_button_text.set('删除按键')
        self.more_info_text.set('更多信息')
        tk.Label(self.title_frame, textvariable=self.talk_to, justify=tk.LEFT, anchor=tk.W, width=40).grid(row=0, rowspan=2, column=0)
        self.more_info_button = tk.Button(self.title_frame, textvariable=self.more_info_text, cursor='hand2', command=self.more_friend_info, fg='#09BB07', relief=tk.FLAT)
        self.more_info_button.grid(row=0, column=1)
        self.more_record_button = tk.Button(self.title_frame, text='更多记录', cursor='hand2', fg='#09BB07', relief=tk.FLAT)
        self.more_record_button.grid(row=1, column=1)
        self.select_files_button = tk.Button(self.title_frame, text='查看文件', cursor='hand2', fg='#09BB07', relief=tk.FLAT)
        self.select_files_button.grid(row=0, column=2)
        self.delete_button = tk.Button(self.title_frame, textvariable=self.delete_button_text, cursor='hand2', fg='#09BB07', relief=tk.FLAT)
        self.delete_button.grid(row=1, column=2)
        self.smtag = tk.PhotoImage(file='swsm.gif')
        tk.Label(self.toplevel, image=self.smtag).grid(row=0, column=5, sticky=tk.E, ipadx=15)

        # 文本框
        self.text = tk.Text(master=self.text_sb_frame, width=60, height=17, fg='#808080', bd=0, state='disable', bg='#F5F5F5', highlightthickness=0)
        self.sby = tk.Scrollbar(self.text_sb_frame, orient=tk.VERTICAL, command=self.text.yview, troughcolor='#F5F5F5', width=8,  bg='#F5F5F5', activebackground="#D2D2D2", bd=0)
        self.sby.grid(row=0, rowspan=3, column=1, sticky=tk.N+tk.S)
        self.sbx = tk.Scrollbar(self.text_sb_frame, orient=tk.HORIZONTAL, command=self.text.xview, troughcolor='#F5F5F5', width=8,  bg='#F5F5F5', activebackground="#D2D2D2", bd=0)
        self.sbx.grid(row=3, column=0, sticky=tk.E+tk.W)
        self.text['yscrollcommand'] = self.sby.set
        self.text['xscrollcommand'] = self.sbx.set
        self.text.grid(row=0, rowspan=3, column=0, sticky=tk.N)

        # 输入框
        self.entry = tk.Text(self.text_frame, width=62, height=7, bd=0, bg='#FFFFFF', fg='#232323', highlightthickness=0)
        self.entry.grid(row=4, rowspan=3, column=0, columnspan=2, sticky=tk.S)

        self.func_frame = tk.Frame(self.text_frame)
        self.func_frame.propagate(0) 
        self.func_frame.grid(row=0, rowspan=4, column=2, sticky=tk.N)

        # 功能按钮
        self.add_friend_button = tk.Button(self.func_frame, text='添加好友', bd=0, command=self.add_friend, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        self.add_friend_button.grid(row=0, column=2, sticky=tk.S)
        self.add_group_button = tk.Button(self.func_frame, text='加入群聊', bd=0, command=self.add_group, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        self.add_group_button.grid(row=1, column=2, sticky=tk.S)
        self.create_group_button = tk.Button(self.func_frame, text='创建群聊', command=self.create_group, bd=0, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        self.create_group_button.grid(row=2, column=2, sticky=tk.S)
        self.translation_button = tk.Button(self.func_frame, text='翻译', width=7, command=self.translation, bd=0, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        self.translation_button.grid(row=3, column=2, sticky=tk.S)
        self.weather_button = tk.Button(self.func_frame, text='天气查询', command=self.weather, bd=0, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        self.weather_button.grid(row=4, column=2, sticky=tk.S)
        self.file_transfer_button = tk.Button(self.text_frame, text='文件传输', command=self.transfer_files_to_friend, bd=0, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        self.file_transfer_button.grid(row=4, column=2, sticky=tk.S)
        self.reinput_button = tk.Button(self.text_frame, text='重新输入', bd=0, command=self.reinput_entry, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        self.reinput_button.grid(row=5, column=2, sticky=tk.S)
        self.send_button = tk.Button(self.text_frame, text='发 送', width=7, command=self.send_friend_message, bd=0, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        self.send_button.grid(row=6, column=2, sticky=tk.S + tk.W)

        self.friends_list()
        self.refresh_friends()

    def translation(self):
        self.translate_toplevel = tk.Toplevel()
        self.translate_toplevel.title('翻译')

        button_frame = tk.Frame(self.translate_toplevel)
        button_frame.grid(row=0, column=0, columnspan=2, sticky=tk.W + tk.E)

        fromLang = tk.StringVar()
        from_lang = ttk.Combobox(button_frame, textvariable=fromLang, justify='center')
        from_lang.grid(row=0, column=0, sticky=tk.W + tk.E)
        from_lang['values'] = lang.lang_tuple
        from_lang.current(23)

        tk.Label(button_frame, text='\u21D2').grid(row=0, column=1)

        toLang = tk.StringVar()
        to_lang = ttk.Combobox(button_frame, textvariable=toLang, justify='center')
        to_lang.grid(row=0, column=2, sticky=tk.W + tk.E)
        to_lang['values'] = lang.lang_tuple
        to_lang.current(22)

        def translate_func():
            content_all = entry.get(0.0, tk.END)
            print('content_all:', content_all)
            # result_r = re.findall(r'(.*)(?:\n)?', content_all)
            # result = []
            # for i in result_r:
            #     if i:
            #         result.append(i)
            result = re.findall(r'(.*)(?:\n)?', content_all)
            print('result:', result)
            text['state'] = 'normal'
            text.delete(0.0, tk.END)
            text['state'] = 'disable'
            text.update()
            for content in result:
                text['state'] = 'normal'
                print('content', content)
                # while True:
                #     try:
                #         dst = translate.baidu_translate(lang.lang_dict['{}'.format(fromLang.get())], lang.lang_dict['{}'.format(toLang.get())], content)
                #         time.sleep(1)
                #         break
                #     except Exception as e:
                #         print('出错了')
                #         continue
                try:
                        dst = translate.baidu_translate(lang.lang_dict['{}'.format(fromLang.get())], lang.lang_dict['{}'.format(toLang.get())], content)
                except Exception as e:
                    print('出错了')
                    text.insert(tk.END, '\n')
                    continue
                print('dst:', dst)
                text.insert(tk.END, dst + '\n')
                text['state'] = 'disable'
                time.sleep(1)
                text.update()
            
        translate_button = tk.Button(button_frame, text='翻译', command=translate_func, bd=0, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        translate_button.grid(row=0, column=3, sticky=tk.E)

        entry_frame = tk.Frame(self.translate_toplevel)
        entry_frame.grid(row=1, column=0, sticky=tk.N + tk.E + tk.W)
        text_frame = tk.Frame(self.translate_toplevel)
        text_frame.grid(row=1, column=1, sticky=tk.N + tk.E + tk.W)
        # 文本框
        text = tk.Text(text_frame, width=50, bd=0, state='disable', bg='#F5F5F5', highlightthickness=0)
        text.grid(row=0, column=0, sticky=tk.N + tk.S + tk.E)
        sby = tk.Scrollbar(text_frame, orient=tk.VERTICAL, command=text.yview, troughcolor='#F5F5F5', width=8,  bg='#F5F5F5', activebackground="#D2D2D2", bd=0)
        sby.grid(row=0,column=1, sticky=tk.S + tk.N)
        sbx = tk.Scrollbar(text_frame, orient=tk.HORIZONTAL, command=text.xview, troughcolor='#F5F5F5', width=8,  bg='#F5F5F5', activebackground="#D2D2D2", bd=0)
        sbx.grid(row=1,column=0, sticky=tk.W + tk.E)
        text['yscrollcommand'] = sby.set
        text['xscrollcommand'] = sbx.set
        # 输入框
        # tk.Label(entry_frame, text='请输入需要翻译的语句:').pack(fill=tk.Y, side=tk.B)
        entry = tk.Text(entry_frame, width=50, bd=0, bg='#FFFFFF', fg='#232323', highlightthickness=0)
        entry.grid(row=0, column=0, sticky=tk.N + tk.S + tk.W)
        sby = tk.Scrollbar(entry_frame, orient=tk.VERTICAL, command=entry.yview, troughcolor='#FFFFFF', width=8,  bg='#FFFFFF', activebackground="#D2D2D2", bd=0)
        sby.grid(row=0,column=1, sticky=tk.S + tk.N)
        sbx = tk.Scrollbar(entry_frame, orient=tk.HORIZONTAL, command=entry.xview, troughcolor='#FFFFFF', width=8,  bg='#FFFFFF', activebackground="#D2D2D2", bd=0)
        sbx.grid(row=1,column=0, sticky=tk.W + tk.E)
        entry['yscrollcommand'] = sby.set
        entry['xscrollcommand'] = sbx.set
        the_fromLang = lang.lang_dict['{}'.format(fromLang.get())]
        the_toLang = lang.lang_dict['{}'.format(toLang.get())]
        print(the_fromLang)
        print(the_toLang)

        # def translate_func():
        #     translate_info = translate.baidu_translate(fromLang, toLang, content.get())
        #     text['state'] = 'normal'
        #     text.delete('0.0', tk.END)
        #     text.insert(0.0, translate_info)
        #     text['state'] = 'disable'
        #     text.see('0.0')

    def weather(self):
        self.weather_toplevel = tk.Toplevel()
        self.weather_toplevel.title('天气查询')
        sw = self.weather_toplevel.winfo_screenwidth()
        sh = self.weather_toplevel.winfo_screenheight()
        self.weather_toplevel.anchor('center')
        alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.weather_toplevel.geometry(alignstr)
        text_frame = tk.Frame(self.weather_toplevel)
        text_frame.pack(side=tk.TOP, fill=tk.BOTH)
        # 文本框
        text = tk.Text(master=text_frame, width=35, bd=0, state='disable', bg='#F5F5F5', highlightthickness=0)
        sby = tk.Scrollbar(text_frame, orient=tk.VERTICAL, command=text.yview, troughcolor='#F5F5F5', width=8,  bg='#F5F5F5', activebackground="#D2D2D2", bd=0)
        sby.pack(side=tk.RIGHT, fill=tk.Y)
        sbx = tk.Scrollbar(text_frame, orient=tk.HORIZONTAL, command=text.xview, troughcolor='#F5F5F5', width=8,  bg='#F5F5F5', activebackground="#D2D2D2", bd=0)
        sbx.pack(side=tk.BOTTOM, fill=tk.X)
        text['yscrollcommand'] = sby.set
        text['xscrollcommand'] = sbx.set
        text.pack(fill=tk.X)

        entry_frame = tk.Frame(self.weather_toplevel)
        entry_frame.pack(side=tk.BOTTOM, fill=tk.BOTH)
        # 输入框
        city = tk.StringVar()
        tk.Label(entry_frame, text='请输入城市:').pack(fill=tk.Y, side=tk.LEFT)
        tk.Entry(entry_frame, textvariable=city, highlightthickness=0).pack(fill=tk.BOTH, side=tk.LEFT, expand=True)
        def query():
            weather_info = weather.weather_query(city.get())
            text['state'] = 'normal'
            text.delete('0.0', tk.END)
            text.insert(0.0, weather_info)
            text['state'] = 'disable'
            text.see('0.0')
        query_button = tk.Button(entry_frame, text='查询', command=query, bd=0, relief=tk.FLAT, activeforeground='#09BB07', bg='#40DD40', cursor='hand2')
        query_button.pack(side=tk.LEFT)

    def select_friend_files(self):
        friend_id = re.match(r"\w{5,20}\(([0-9]{12})\)", self.selected_friend).group(1)
        self.s.sendto('U {} to U {} select files'.format(self.user_id.get(), friend_id).encode(), self.ADDR)

    def select_group_files(self):
        group_id = re.match(r"\w{5,20}\(([0-9]{10})\)", self.selected_group).group(1)
        self.s.sendto('U {} to G {} select files'.format(self.user_id.get(), group_id).encode(), self.ADDR)

    def friend_files_list_interface(self, friend_id, files_tup):
        self.friend_files_list_toplevel = tk.Toplevel()
        self.friend_files_list_friend_id = friend_id
        self.friend_files_list_toplevel.title('与好友{}的文件列表'.format(friend_id))
        # self.friend_files_list_toplevel.geometry('600x100')
        self.friend_files_list = ttk.Treeview(self.friend_files_list_toplevel, show='headings')
        self.friend_files_list["columns"]=("文件名", "上传时间", "文件大小", "上传者")
        self.friend_files_list.column("文件名", width=200, anchor='center')
        self.friend_files_list.column("上传时间", width=150, anchor='center')
        self.friend_files_list.column("文件大小", width=100, anchor='center')
        self.friend_files_list.column("上传者", width=100, anchor='center')
        self.friend_files_list.heading("文件名", text='文件名')
        self.friend_files_list.heading("上传时间", text="上传时间")
        self.friend_files_list.heading("文件大小", text="文件大小")
        self.friend_files_list.heading("上传者", text="上传者")
        for file_tup in files_tup:
            if file_tup[4] > 10 ** 8:
                size = '{:.2f}G'.format(file_tup[4] / 10 ** 9)
            elif file_tup[4] > 10 ** 5:
                size = '{:.2f}M'.format(file_tup[4] / 10 ** 6)
            elif file_tup[4] > 10 ** 2:
                size = '{:.2f}K'.format(file_tup[4] / 10 ** 3)
            else:
                size = '{:.2f}B'.format(file_tup[4])
            self.friend_files_list.insert('', 0, text='{}'.format(file_tup[0]), values=(file_tup[3], file_tup[5], size, file_tup[1]))
        self.friend_files_list.pack(fill=tk.BOTH)
        self.friend_files_list.bind('<Double-1>', self.down_load_file_from_friend)

    def group_files_list_interface(self, group_id, files_tup):
        self.group_files_list_toplevel = tk.Toplevel()
        self.group_files_list_group_id = group_id
        self.group_files_list_toplevel.title('群{}文件列表'.format(group_id))
        # self.group_files_list_toplevel.geometry('600x100')
        self.group_files_list = ttk.Treeview(self.group_files_list_toplevel, show='headings')
        self.group_files_list["columns"]=("文件名", "上传时间", "文件大小", "上传者")
        self.group_files_list.column("文件名", width=200, anchor='center')
        self.group_files_list.column("上传时间", width=150, anchor='center')
        self.group_files_list.column("文件大小", width=100, anchor='center')
        self.group_files_list.column("上传者", width=100, anchor='center')
        self.group_files_list.heading("文件名", text='文件名')
        self.group_files_list.heading("上传时间", text="上传时间")
        self.group_files_list.heading("文件大小", text="文件大小")
        self.group_files_list.heading("上传者", text="上传者")
        for file_tup in files_tup:
            if file_tup[4] > 10 ** 8:
                size = '{:.2f}G'.format(file_tup[4] / 10 ** 9)
            elif file_tup[4] > 10 ** 5:
                size = '{:.2f}M'.format(file_tup[4] / 10 ** 6)
            elif file_tup[4] > 10 ** 2:
                size = '{:.2f}K'.format(file_tup[4] / 10 ** 3)
            else:
                size = '{:.2f}B'.format(file_tup[4])
            self.group_files_list.insert('', 0, text='{}'.format(file_tup[0]), values=(file_tup[3], file_tup[5], size, file_tup[1]))
        self.group_files_list.pack(fill=tk.BOTH)
        self.group_files_list.bind('<Double-1>', self.down_load_file_from_group)

    def down_load_file_from_friend(self, event):
        item = self.friend_files_list.selection()[0]
        file_id = self.friend_files_list.item(item, 'text')
        values = self.friend_files_list.item(item, 'values')
        file_name = values[0]
        from_id = values[-1]
        self.down_load_file_confirm = tk.Toplevel()
        self.down_load_file_confirm.title('传输文件')
        sw = self.down_load_file_confirm.winfo_screenwidth()
        sh = self.down_load_file_confirm.winfo_screenheight()
        self.down_load_file_confirm.anchor('center')
        alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.down_load_file_confirm.geometry(alignstr)
        tk.Label(self.down_load_file_confirm, text='    要下载文件{}吗?    '.format(file_name)).grid(row=0, column=0)
        def down_load_the_file_from_friend():
            self.s.sendto('U {} to U {} down file {} id {} from {}'.format(self.user_id.get(), self.friend_files_list_friend_id, file_name, file_id, from_id).encode(), self.ADDR)
        tk.Button(self.down_load_file_confirm, text='确定', command=down_load_the_file_from_friend).grid(row=1, column=0)

    def down_load_file_from_group(self, event):
        item = self.group_files_list.selection()[0]
        file_id = self.group_files_list.item(item, 'text')
        values = self.group_files_list.item(item, 'values')
        file_name = values[0]
        from_id = values[-1]
        self.down_load_file_confirm = tk.Toplevel()
        self.down_load_file_confirm.title('传输文件')
        sw = self.down_load_file_confirm.winfo_screenwidth()
        sh = self.down_load_file_confirm.winfo_screenheight()
        self.down_load_file_confirm.anchor('center')
        alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.down_load_file_confirm.geometry(alignstr)
        tk.Label(self.down_load_file_confirm, text='    要下载文件{}吗?    '.format(file_name)).grid(row=0, column=0)
        def down_load_the_file_from_group():
            self.s.sendto('U {} to G {} down file {} id {} from {}'.format(self.user_id.get(), self.group_files_list_group_id, file_name, file_id, from_id).encode(), self.ADDR)
            print('发送了')
        tk.Button(self.down_load_file_confirm, text='确定', command=down_load_the_file_from_group).grid(row=1, column=0)

    def transfer_files_to_friend(self):
        self.transfer_files_to_friend_toplevel = tk.Toplevel()
        self.transfer_files_to_friend_toplevel.title('传输文件')
        sw = self.transfer_files_to_friend_toplevel.winfo_screenwidth()
        sh = self.transfer_files_to_friend_toplevel.winfo_screenheight()
        self.transfer_files_to_friend_toplevel.anchor('center')
        self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.transfer_files_to_friend_toplevel.geometry(self.alignstr)
        self.path = tk.StringVar()
        tk.Label(self.transfer_files_to_friend_toplevel, text='传输文件给好友{}:'.format(self.selected_friend), fg='grey', justify=tk.LEFT).grid(row=0, column=0, sticky=tk.W)
        tk.Label(self.transfer_files_to_friend_toplevel, text='请输入文件路径:', justify=tk.LEFT).grid(row=1, column=0, sticky=tk.W)
        tk.Entry(self.transfer_files_to_friend_toplevel, textvariable=self.path, width=65, highlightthickness=0).grid(row=2, column=0)
        tk.Button(self.transfer_files_to_friend_toplevel, text='发送', command=self.send_friend_file).grid(row=3, column=0)

    def transfer_files_to_group(self):
        self.transfer_files_to_group_toplevel = tk.Toplevel()
        self.transfer_files_to_group_toplevel.title('传输文件')
        sw = self.transfer_files_to_group_toplevel.winfo_screenwidth()
        sh = self.transfer_files_to_group_toplevel.winfo_screenheight()
        self.transfer_files_to_group_toplevel.anchor('center')
        self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.transfer_files_to_group_toplevel.geometry(self.alignstr)
        self.group_file_path = tk.StringVar()
        tk.Label(self.transfer_files_to_group_toplevel, text='传输文件给好友{}:'.format(self.selected_group), fg='grey', justify=tk.LEFT).grid(row=0, column=0, sticky=tk.W)
        tk.Label(self.transfer_files_to_group_toplevel, text='请输入文件路径:', justify=tk.LEFT).grid(row=1, column=0, sticky=tk.W)
        tk.Entry(self.transfer_files_to_group_toplevel, textvariable=self.group_file_path, width=65, highlightthickness=0).grid(row=2, column=0)
        tk.Button(self.transfer_files_to_group_toplevel, text='发送', command=self.send_group_file).grid(row=3, column=0)

    def send_friend_file(self):
        path = self.path.get()
        result = os.path.exists(path)
        if not result:
            mb.showerror('文件传输', '该路径不存在!')
            return
        result = os.path.isfile(path)
        if not result:
            mb.showerror('文件传输', '这不是个文件!')
            return
        file_name = os.path.basename(path)
        file_size = os.path.getsize(path)
        if not file_size:
            mb.showerror('文件传输', '文件不能为空!')
        friend_id = re.match(r'\w{5,20}\(([0-9]{12})\)', self.selected_friend).group(1)
        self.s.sendto('U {} to U {} send {} size {} path {}'.format(self.user_id.get(), friend_id, file_name, file_size, path).encode(), self.ADDR)
        mb.showinfo('文件传输', '    正在开始发送!    ')

    def send_group_file(self):
        path = self.group_file_path.get()
        result = os.path.exists(path)
        if not result:
            mb.showerror('文件传输', '该路径不存在!')
            return
        result = os.path.isfile(path)
        if not result:
            mb.showerror('文件传输', '这不是个文件!')
            return
        file_name = os.path.basename(path)
        file_size = os.path.getsize(path)
        if not file_size:
            mb.showerror('文件传输', '文件不能为空!')
        group_id = re.match(r'\w{5,20}\(([0-9]{10})\)', self.selected_group).group(1)
        self.s.sendto('U {} to G {} send {} size {} path {}'.format(self.user_id.get(), group_id, file_name, file_size, path).encode(), self.ADDR)
        mb.showinfo('文件传输', '    正在开始发送!    ')

    def delete_friend(self):
        self.delete_friend_toplevel = tk.Toplevel()
        self.delete_friend_toplevel.title('删除好友')
        sw = self.delete_friend_toplevel.winfo_screenwidth()
        sh = self.delete_friend_toplevel.winfo_screenheight()
        self.delete_friend_toplevel.anchor('center')
        self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.delete_friend_toplevel.geometry(self.alignstr)
        tk.Label(self.delete_friend_toplevel, text='你要删除你的好友{}吗?'.format(self.selected_friend), width=100, pady=10).grid(row=0, column=0)
        tk.Button(self.delete_friend_toplevel, text='确定', command=self.already_delete_friend).grid(row=1, column=0)

    def delete_group(self):
        self.delete_group_toplevel = tk.Toplevel()
        self.delete_group_toplevel.title('退出群聊')
        sw = self.delete_group_toplevel.winfo_screenwidth()
        sh = self.delete_group_toplevel.winfo_screenheight()
        self.delete_group_toplevel.anchor('center')
        self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.delete_group_toplevel.geometry(self.alignstr)
        tk.Label(self.delete_group_toplevel, text='你要退出群号为{}的群吗?'.format(self.selected_group), width=100, pady=10).grid(row=0, column=0)
        tk.Button(self.delete_group_toplevel, text='确定', command=self.already_delete_group).grid(row=1, column=0)

    def create_group(self):
        self.create_group_toplevel = tk.Toplevel()
        self.create_group_toplevel.title('创建群聊')
        sw = self.create_group_toplevel.winfo_screenwidth()
        sh = self.create_group_toplevel.winfo_screenheight()
        self.create_group_toplevel.anchor('center')
        self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.create_group_toplevel.geometry(self.alignstr)
        self.group_id = tk.StringVar()
        self.group_name = tk.StringVar()
        tk.Label(self.create_group_toplevel).grid(row=0, stick=tk.W, pady=10, padx=10)
        tk.Label(self.create_group_toplevel, text='群 号: ').grid(row=1, column=0, sticky=tk.E, pady=10, padx=10)
        tk.Entry(self.create_group_toplevel, textvariable=self.group_id, validate='focusout', vcmd=self.group_id_check, invcmd=self.group_id_error,
                 width=25, highlightthickness=0).grid(row=1, column=1, columnspan=3, stick=tk.W)
        tk.Label(self.create_group_toplevel, text='由10位数字组成', fg='grey').grid(row=1, column=4, stick=tk.W, padx=10)
        tk.Label(self.create_group_toplevel, text='群 名: ').grid(row=2, column=0, sticky=tk.E, pady=10, padx=10)
        tk.Entry(self.create_group_toplevel, textvariable=self.group_name, validate='focusout', vcmd=self.group_name_check, invcmd=self.group_name_error,
                 width=25, highlightthickness=0).grid(row=2, column=1, columnspan=3, stick=tk.W)
        tk.Label(self.create_group_toplevel, text='由5-20位文字符号组成', fg='grey').grid(row=2, column=4, stick=tk.W, padx=10)
        tk.Button(self.create_group_toplevel, text='确定', command=self.group_create).grid(row=5, column=0, columnspan=2, pady=20, padx=10)
        tk.Button(self.create_group_toplevel, text="取消", command=self.group_cancel).grid(row=5, column=2, columnspan=2, pady=10, padx=10, stick=tk.E)
    
    def group_id_check(self):
        group_id_result = re.match(r"^[0-9]{10}$", self.group_id.get())
        if group_id_result:
            return True
        else:
            return False

    def group_id_error(self):
        mb.showerror('群号错误', '群号由10位数字组成!')

    def group_name_check(self):
        group_name_result = re.match(r"^\w{5,20}$", self.group_name.get())
        if group_name_result:
            return True
        else:
            return False   

    def group_name_error(self):
        mb.showerror('群名错误', '群名由5-20位文字符号组成!')

    def group_create(self):
        if not (self.group_id_check() and self.group_name_check()):
            mb.showerror('创建失败', '输入错误!           ')
            return
        # self.create_group_toplevel.destroy()
        self.s.sendto('G {} {} U {} {} create'.format(self.group_id.get(), self.group_name.get(), self.user_id.get(), self.user_name).encode(), self.ADDR)
        self.group_id.set('')
        self.group_name.set('')

    # def id_error(self):
    #     mb.showerror('账户错误', '账户由12位数字组成!')

    # def name_error(self):
    #     mb.showerror('昵称错误', '昵称由5-20位文字符号组成!')

    def group_cancel(self):
        self.create_group_toplevel.destroy()

    def already_delete_friend(self):
        self.delete_friend_toplevel.destroy()
        friend_id = re.match(r"\w{5,20}\(([0-9]{12})\)", self.selected_friend).group(1)
        for friend_text in self.friends:
            print(friend_text[0], friend_id)
            if friend_text[0] == friend_id:
                self.index = self.friends.index(friend_text)
                self.friends.remove(friend_text)
                print(self.index)
                self.s.sendto('U {} D U {}'.format(self.user_id.get(), friend_id).encode(), self.ADDR)
                self.delete_friend_toplevel = tk.Toplevel()
                self.delete_friend_toplevel.title('删除好友')
                sw = self.delete_friend_toplevel.winfo_screenwidth()
                sh = self.delete_friend_toplevel.winfo_screenheight()
                self.delete_friend_toplevel.anchor('center')
                self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
                self.delete_friend_toplevel.geometry(self.alignstr)
                self.talk_to.set('')
                self.text['state'] = 'normal'
                self.text.delete(1.0, tk.END)
                self.text['state'] = 'disable'
                tk.Label(self.delete_friend_toplevel, text='已删除好友{}并删除了聊天记录?'.format(self.selected_friend), pady=10).grid(row=0, column=0)
                self.delete_friend_toplevel.destroy()
                break
        self.my_friends.delete(self.index)

    def already_delete_group(self):
        self.delete_group_toplevel.destroy()
        group_id = re.match(r"\w{5,20}\(([0-9]{10})\)", self.selected_group).group(1)
        for group_text in self.groups:
            if group_text[0] == group_id:
                self.index = self.groups.index(group_text)
                self.groups.remove(group_text)
                print(self.index)
                self.s.sendto('U {} D G {}'.format(self.user_id.get(), group_id).encode(), self.ADDR)
                self.delete_group_toplevel = tk.Toplevel()
                self.delete_group_toplevel.title('退出群聊')
                sw = self.delete_group_toplevel.winfo_screenwidth()
                sh = self.delete_group_toplevel.winfo_screenheight()
                self.delete_group_toplevel.anchor('center')
                self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
                self.delete_group_toplevel.geometry(self.alignstr)        
                self.talk_to.set('')
                self.text['state'] = 'normal'
                self.text.delete(1.0, tk.END)
                self.text['state'] = 'disable'
                tk.Label(self.delete_group_toplevel, text='已退出群号为{}的群聊并删除了聊天记录'.format(self.selected_group), pady=10).grid(row=0, column=0)
                self.delete_group_toplevel.destroy()
                break
        self.my_groups.delete(self.index)

    def delete_friend_from_list(self):
        self.my_friends.delete(self.index)
        self.talk_to.set('')
        self.text['state'] = 'normal'
        self.text.delete(1.0, tk.END)
        self.text['state'] = 'disable'
        self.delete_friend_toplevel.destroy()

    def delete_group_from_list(self):
        # group_id = re.match(r"\w{5,20}\(([0-9]{10})\)", self.selected_group).group(1)
        for group_text in self.groups:
            if group_text[0] == self.delete_group_id:
                self.index = self.groups.index(group_text)
                self.groups.remove(group_text)
        self.my_groups.delete(self.index)
        self.talk_to.set('')
        self.text['state'] = 'normal'
        self.text.delete(1.0, tk.END)
        self.text['state'] = 'disable'
        self.delete_group_toplevel.destroy()

    def already_not_friend(self, friend_id):
        self.delete_friend_toplevel = tk.Toplevel()
        self.delete_friend_toplevel.title('删除好友')
        sw = self.delete_friend_toplevel.winfo_screenwidth()
        sh = self.delete_friend_toplevel.winfo_screenheight()
        self.delete_friend_toplevel.anchor('center')
        self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.delete_friend_toplevel.geometry(self.alignstr)
        tk.Label(self.delete_friend_toplevel, text='{}早已不是你好友, 自己干了什么心里没点B数吗'.format(self.selected_friend), pady=10).grid(row=0, column=0)
        tk.Button(self.delete_friend_toplevel, text='删除记录', command=self.delete_friend_from_list).grid(row=1, column=0)

    def already_not_member(self, group_id):
        self.delete_group_toplevel = tk.Toplevel()
        self.delete_group_toplevel.title('退出群聊')
        sw = self.delete_group_toplevel.winfo_screenwidth()
        sh = self.delete_group_toplevel.winfo_screenheight()
        self.delete_group_toplevel.anchor('center')
        self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.delete_group_toplevel.geometry(self.alignstr)
        self.delete_group_id = group_id
        tk.Label(self.delete_group_toplevel, text='你已经被踢出群号为{}的群聊了, 自己干了什么心里没点B数吗'.format(self.selected_group), pady=10).grid(row=0, column=0)
        tk.Button(self.delete_group_toplevel, text='删除记录', command=self.delete_group_from_list).grid(row=1, column=0)

    def delete_friend_from_list(self):
        self.my_friends.delete(self.index)
        self.talk_to.set('')
        self.text['state'] = 'normal'
        self.text.delete(1.0, tk.END)
        self.text['state'] = 'disable'
        self.delete_friend_toplevel.destroy()

    def more_friend_info(self):
        mb.showinfo(self.selected_friend, '%s: 够了, 没有更多了' % self.selected_friend)

    def reinput_entry(self):
        self.entry.delete(1.0, tk.END)

    def send_friend_message(self):
        content = self.entry.get('0.0', 'end')
        self.entry.delete('0.0', 'end')
        msg = re.match(r'^\w{5,20}\n\(([0-9]{12})\)', self.talk_to.get())
        if msg:
            result = msg.group(1)
            for friend_text in self.friends:
                if friend_text[0] == result:
                    self.s.sendto('U {} to U {} C {}'.format(self.user_id.get(), result, content).encode(), self.ADDR)
                    return
            self.delete_friend_toplevel = tk.Toplevel()
            self.delete_friend_toplevel.title('删除好友')
            tk.Label(self.delete_friend_toplevel, text='{}早已不是你好友, 自己干了什么心里没点B数吗'.format(self.selected_friend), pady=10).grid(row=0, column=0)
            tk.Button(self.delete_friend_toplevel, text='删除记录', command=self.delete_friend_from_list).grid(row=1, column=0)

    def send_group_message(self):
        content = self.entry.get('0.0', 'end')
        self.entry.delete('0.0', 'end')
        msg = re.match(r'^\w{5,20}\n\(([0-9]{10})\)', self.talk_to.get())
        if msg:
            result = msg.group(1)
            for group_text in self.groups:
                if group_text[0] == result:
                    self.s.sendto('U {} to G {} C {}'.format(self.user_id.get(), result, content).encode(), self.ADDR)
                    return
            self.delete_group_toplevel = tk.Toplevel()
            self.delete_group_toplevel.title('删除好友')
            tk.Label(self.delete_group_toplevel, text='{}早已不是你好友, 自己干了什么心里没点B数吗'.format(self.selected_group), pady=10).grid(row=0, column=0)
            tk.Button(self.delete_group_toplevel, text='删除记录', command=self.delete_group_from_list).grid(row=1, column=0)

    def more_friend_record(self):
        if self.talk_to.get():
            friend_id = re.match(r"\w{5,20}\(([0-9]{12})\)", self.selected_friend).group(1)
            for friend_text in self.friends:
                if friend_text[0] == friend_id:
                    if friend_text.text:
                        earliest_id = friend_text.text[0][0]
                        self.s.sendto('U {} to U {} m {}'.format(self.user_id.get(), friend_id,  earliest_id).encode(), self.ADDR)
                    else:
                        self.s.sendto('U {} to U {} m '.format(self.user_id.get(), friend_id).encode(), self.ADDR)


    def add_friend(self):
        self.select_friend = tk.StringVar()
        self.add_friend_toplevel = tk.Toplevel()
        sw = self.add_friend_toplevel.winfo_screenwidth()
        sh = self.add_friend_toplevel.winfo_screenheight()
        self.add_friend_toplevel.anchor('center')
        self.pot = '+%d+%d' % (sw / 2, sh/ 2)
        self.add_friend_toplevel.title("添加好友")
        self.add_friend_toplevel.geometry(self.pot)
        self.add_friend_entry = tk.Entry(self.add_friend_toplevel, textvariable=self.select_friend, highlightthickness=0)
        self.add_friend_entry.grid(row=0, column=0)
        tk.Button(self.add_friend_toplevel, text='添加', command=self.find_friend).grid(row=1, column=0)

    def add_group(self):
        self.select_group = tk.StringVar()
        self.add_group_toplevel = tk.Toplevel()
        sw = self.add_group_toplevel.winfo_screenwidth()
        sh = self.add_group_toplevel.winfo_screenheight()
        self.add_group_toplevel.anchor('center')
        self.pot = '+%d+%d' % (sw / 2, sh/ 2)
        self.add_group_toplevel.title("加入群聊")
        self.add_group_toplevel.geometry(self.pot)
        self.add_group_entry = tk.Entry(self.add_group_toplevel, textvariable=self.select_group, highlightthickness=0)
        self.add_group_entry.grid(row=0, column=0)
        tk.Button(self.add_group_toplevel, text='添加', command=self.find_group).grid(row=1, column=0)

    def find_friend(self):
        result = re.match(r"^[0-9]{12}$", self.select_friend.get())
        if not result:
            mb.showerror('账户错误', '账户由12位数字组成!')
        else:
            for friend_text in self.friends:
                if friend_text[0] == self.select_friend.get():
                    mb.showinfo('系统消息', '你和{}已经是好友了'.format(self.select_friend.get()))
                    return
            self.s.sendto('U {} to U {} A '.format(self.user_id.get(), self.select_friend.get()).encode(), self.ADDR)
            mb.showinfo('系统消息', '发送成功')

    def find_group(self):
        result = re.match(r"^[0-9]{10}$", self.select_group.get())
        if not result:
            mb.showerror('群号错误', '群号由10位数字组成!')
        else:
            self.s.sendto('U {} to G {} A '.format(self.user_id.get(), self.select_group.get()).encode(), self.ADDR)
            mb.showinfo('系统消息', '发送成功')

    def add_friend_message(self, the_id):
        def refuse():
            self.s.sendto('U {} R U {}'.format(self.user_id.get(), the_id).encode(), self.ADDR)
            self.add_friend_message_toplevel.destroy()
        def agreed():
            self.s.sendto('U {} A U {}'.format(self.user_id.get(), the_id).encode(), self.ADDR)
            self.add_friend_message_toplevel.destroy()
        self.add_friend_message_toplevel = tk.Toplevel()
        self.add_friend_message_toplevel.title('系统消息')
        msg = 'id号为{}的用户想添加您为好友'.format(the_id)
        tk.Label(self.add_friend_message_toplevel, text=msg, width=50, height=3).grid(row=0, column=0, columnspan=2)
        tk.Button(self.add_friend_message_toplevel, text='拒绝', command=refuse).grid(row=1, column=0)
        tk.Button(self.add_friend_message_toplevel, text='同意', command=agreed).grid(row=1, column=1)

    def add_group_message(self, from_id, group_id):
        def refuse():
            self.s.sendto('G {} R U {}'.format(group_id, from_id).encode(), self.ADDR)
            self.add_group_message_toplevel.destroy()
        def agreed():
            self.s.sendto('G {} A U {}'.format(group_id, from_id).encode(), self.ADDR)
            self.add_group_message_toplevel.destroy()
        self.add_group_message_toplevel = tk.Toplevel()
        self.add_group_message_toplevel.title('系统消息')
        msg = 'id号为{}的用户想加入您群号为{}的群'.format(from_id, group_id)
        tk.Label(self.add_group_message_toplevel, text=msg, width=50, height=3).grid(row=0, column=0, columnspan=2)
        tk.Button(self.add_group_message_toplevel, text='拒绝', command=refuse).grid(row=1, column=0)
        tk.Button(self.add_group_message_toplevel, text='同意', command=agreed).grid(row=1, column=1)

    def friends_list(self):
        self.talk_to.set('')
        self.selected_friend = '系统'
        self.selected_group = '系统'
        self.more_info_button['command'] = self.more_friend_info
        self.delete_button_text.set('删除按键')
        self.delete_button['command'] = lambda : 1 + 1
        self.file_transfer_button['command'] = lambda : 1 + 1
        self.select_files_button['command'] = lambda : 1 + 1
        self.more_info_text.set('更多信息')
        self.text['state'] = 'normal'
        self.text.delete(1.0, tk.END)
        self.text['state'] = 'disable'
        if self.list_frame:
            self.list_frame.destroy()
        self.friends_button['fg'] = 'white'
        # self.friends_button['state'] = 'disabled'
        self.friends_button['relief'] = tk.SUNKEN
        self.friends_button['bg'] = '#BFBFBF'
        # self.groups_button['state'] = 'normal'
        self.groups_button['relief'] = tk.FLAT
        self.groups_button['bg'] = '#D9D9D9'
        self.groups_button['fg'] = '#09BB07'
        self.send_button['command'] = self.send_friend_message
        self.entry['state'] = 'disable'
        self.list_frame = tk.Frame(self.toplevel, width=20)
        self.list_frame.propagate(0) 
        self.list_frame.grid(row=1, rowspan=2, column=0, columnspan=2)
        self.my_friends = tk.Listbox(self.list_frame, selectmode = tk.BROWSE, height=18, bg='#EEEAE8', highlightthickness=0, bd=0)
        sby = tk.Scrollbar(self.list_frame, orient=tk.VERTICAL, command=self.my_friends.yview, troughcolor='#EEEAE8', width=8,  bg='#EEEAE8', activebackground="#D2D2D2", bd=0)
        # sby.activate('arrow1')
        sby.grid(column=1, sticky=tk.N+tk.S)
        sbx = tk.Scrollbar(self.list_frame, orient=tk.HORIZONTAL, command=self.my_friends.xview, troughcolor='#EEEAE8', width=8,  bg='#EEEAE8', activebackground="#D2D2D2", bd=0)
        sbx.grid(row=1, sticky=tk.E+tk.W) 
        self.my_friends['yscrollcommand'] = sby.set
        self.my_friends['xscrollcommand'] = sbx.set
        self.my_friends.grid(row=0, column=0)
        self.refresh_friends()
        self.my_friends.bind('<Double-Button-1>', self.friend_interface)
        # self.my_friends.get(my_friends.curselection())

    def refresh_friends(self):
        self.friends.sort(key=lambda x: x[1])
        self.my_friends.delete(0, tk.END)
        fore_item = ''
        for item in self.friends:
            if item[0] != fore_item:
                self.my_friends.insert(tk.END, '{}({})'.format(item[1], item[0]))
            fore_item = item[0]

    def refresh_groups(self):
        self.groups.sort(key=lambda x: x[1])
        self.my_groups.delete(0, tk.END)
        fore_item = ''
        for item in self.groups:
            if item[0] != fore_item:
                self.my_groups.insert(tk.END, '{}({})'.format(item[1], item[0]))
            fore_item = item[0]

    def refresh_friend_text(self, friend_id, friend_name, text_id, the_id, the_name, the_text, text_time):
        for friend_text in self.friends:
            if friend_text[0] == friend_id:
                if the_id != self.user_id.get():
                    index = self.friends.index(friend_text)
                    print('index', index)
                    self.my_friends.itemconfig(index, {'bg': 'green'})
                friend_text.text.append((int(text_id), the_id, the_name, the_text, text_time))
                print(friend_text.text)
                friend_text.text.sort(key=lambda x: x[0])

    def refresh_group_text(self, group_id, group_name, text_id, the_id, the_name, the_text, text_time):
        for group_text in self.groups:
            if group_text[0] == group_id:
                if the_id != self.user_id.get():
                    index = self.groups.index(group_text)
                    print('index', index)
                    self.my_groups.itemconfig(index, {'bg': 'green'})
                group_text.text.append((int(text_id), the_id, the_name, the_text, text_time))
                print(group_text.text)
                group_text.text.sort(key=lambda x: x[0])



    def friend_interface(self, event):
        self.more_info_button['command'] = self.more_friend_info
        self.more_record_button['command'] = self.more_friend_record
        self.select_files_button['command'] = self.select_friend_files
        self.delete_button['command'] = self.delete_friend
        self.file_transfer_button['command'] = self.transfer_files_to_friend
        self.delete_button_text.set('删除好友')
        self.more_info_text.set('好友信息')
        if self.my_friends.curselection():
            self.entry['state'] = 'normal'
            self.selected_friend = self.my_friends.get(self.my_friends.curselection())
            self.my_friends.itemconfig(self.my_friends.curselection(), {'bg': '#EEEAE8'})
            self.friend_interface_refresh()

    def friend_interface_refresh(self):
        result = re.match(r"\w{5,20}\(([0-9]{12})\)", self.selected_friend)
        if result:
            friend_id = result.group(1)
            for friend_text in self.friends:
                if friend_text[0] == friend_id:
                    self.talk_to.set('{}\n({})'.format(friend_text[1], friend_text[0]))
                    self.text.config(state='normal')
                    self.text.delete(1.0, tk.END)
                    for text in friend_text.text:
                        print(text)
                        time = '    ————' + text[4] + '————' + '\n\n'
                        self.text.insert(tk.END, time)
                        name = '{}({})\n'.format(text[2], text[1])
                        self.text.insert(tk.END, name)
                        content = text[3]
                        print(text[3])
                        result = re.findall(r'(.*)(\n)', content)
                        # label = tk.Label(self.text, text=content, bg='#9EEA6A', fg='#232323', justify=tk.LEFT, padx=10)
                        lst = list(map(lambda x: x[0], result)) if result else [content]
                        print(lst)
                        lengh = list(map(lambda x: len(x) + len(re.findall(r'[\u4e00-\u9fCb]', x)), lst))
                        width = max(lengh)
                        print(width)
                        height = len(result)
                        tag = tk.Text(self.text, bg='#9EEA6A', fg='#232323', width=width, height=height+1, padx=10, pady=10, bd=0, highlightthickness=0)
                        tag.insert(tk.END, content)
                        if text[1] == self.user_id.get():
                            tag ['bg'] = 'white'
                        tag['state'] = 'disable'
                        self.text.window_create(tk.END, window=tag )
                        self.text.insert(tk.END, '\n\n\n')
                    self.text.config(state='disable')
                    self.text.see(tk.END)
            self.toplevel.update()


        # tk.Label(self.toplevel, textvariable=self.talk_to).grid(row=0, column=2, columnspan=3)
       # # 文本框

    def groups_list(self):
        self.talk_to.set('')
        self.selected_friend = '系统'
        self.selected_group = '系统'
        self.more_info_button['command'] = self.more_friend_info
        self.delete_button_text.set('退出按键')
        self.delete_button['command'] = lambda : 1 + 1
        self.more_info_text.set('更多信息')
        self.file_transfer_button['command'] = lambda : 1 + 1
        self.select_files_button['command'] = lambda : 1 + 1
        self.text['state'] = 'normal'
        self.text.delete(1.0, tk.END)
        self.text['state'] = 'disable'
        if self.list_frame:
            self.list_frame.destroy()
        self.friends_button['state'] = 'normal'
        self.friends_button['relief'] = tk.FLAT
        # self.groups_button['state'] = 'disabled'
        self.groups_button['relief'] = tk.SUNKEN
        self.groups_button['bg'] = '#BFBFBF'
        self.friends_button['bg'] = '#D9D9D9'
        self.friends_button['fg'] = '#09BB07'
        self.groups_button['fg'] = 'white'
#         self.friends_button['bg'] = '#BFBFBF'
#         self.friends_button['fg'] = 'white'
# self.groups_button['bg'] = '#D9D9D9'
#         self.groups_button['fg'] = '#09BB07'
        self.entry['state'] = 'disable'
        self.send_button['command'] = self.send_group_message
        self.list_frame = tk.Frame(self.toplevel, width=20)
        self.list_frame.propagate(0) 
        self.list_frame.grid(row=1, rowspan=2, column=0, columnspan=2)
        self.my_groups = tk.Listbox(self.list_frame, selectmode = tk.BROWSE, height=18, bg='#EEEAE8', highlightthickness=0, bd=0)
        sby = tk.Scrollbar(self.list_frame, orient=tk.VERTICAL, command=self.my_groups.yview, troughcolor='#EEEAE8', width=8,  bg='#EEEAE8', activebackground="#D2D2D2", bd=0)
        sby.grid(column=1, sticky=tk.N+tk.S)
        sbx = tk.Scrollbar(self.list_frame, orient=tk.HORIZONTAL, command=self.my_groups.xview, troughcolor='#EEEAE8', width=8,  bg='#EEEAE8', activebackground="#D2D2D2", bd=0)
        sbx.grid(row=1, sticky=tk.E+tk.W) 
        self.my_groups['yscrollcommand'] = sby.set
        self.my_groups['xscrollcommand'] = sbx.set
        self.my_groups.grid(row=0, column=0)
        self.refresh_groups()
        self.my_groups.bind('<Double-Button-1>', self.group_interface)

    def group_interface(self, event):
        self.more_info_button['command'] = self.more_group_info
        self.more_record_button['command'] = self.more_group_record
        self.select_files_button['command'] = self.select_group_files
        self.delete_button['command'] = self.delete_group
        self.delete_button_text.set('退出群聊')
        self.file_transfer_button['command'] = self.transfer_files_to_group
        self.more_info_text.set('群聊成员')
        if self.my_groups.curselection():
            self.entry['state'] = 'normal'
            self.selected_group = self.my_groups.get(self.my_groups.curselection())
            self.my_groups.itemconfig(self.my_groups.curselection(), {'bg': '#EEEAE8'})
            self.talk_to.set('')
            self.group_interface_refresh()

    def group_interface_refresh(self):          
        result = re.match(r"\w{5,20}\(([0-9]{10})\)", self.selected_group)
        if result:
            group_id = result.group(1)
            for group_text in self.groups:
                if group_text[0] == group_id:
                    print(group_text[2], self.user_id.get())
                    if group_text[2] == self.user_id.get():
                        self.delete_button_text.set('解散群聊')
                    self.talk_to.set('{}\n({})'.format(group_text[1], group_text[0]))
                    self.text.config(state='normal')
                    self.text.delete(1.0, tk.END)
                    for text in group_text.text:
                        print(text)
                        time = '    ————' + text[4] + '————' + '\n\n'
                        self.text.insert(tk.END, time)
                        name = '{}({})\n'.format(text[2], text[1])
                        self.text.insert(tk.END, name)
                        content = text[3]
                        print(text[3])
                        result = re.findall(r'(.*)(\n)', content)
                        # label = tk.Label(self.text, text=content, bg='#9EEA6A', fg='#232323', justify=tk.LEFT, padx=10)
                        lst = list(map(lambda x: x[0], result)) if result else [content]
                        print(lst)
                        lengh = list(map(lambda x: len(x) + len(re.findall(r'[\u4e00-\u9fCb]', x)), lst))
                        width = max(lengh)
                        print(width)
                        height = len(result)
                        tag = tk.Text(self.text, bg='#9EEA6A', fg='#232323', width=width, height=height+1, padx=10, pady=10, bd=0, highlightthickness=0)
                        tag.insert(tk.END, content)
                        if text[1] == self.user_id.get():
                            tag ['bg'] = 'white'
                        tag['state'] = 'disable'
                        self.text.window_create(tk.END, window=tag )
                        self.text.insert(tk.END, '\n\n\n')
                    self.text.config(state='disable')
                    self.text.see(tk.END)
            self.toplevel.update()

    def more_group_info(self):
        result = re.match(r"\w{5,20}\(([0-9]{10})\)", self.selected_group)
        if result:
            group_id = result.group(1)
            for group_text in self.groups:
                if group_text[0] == group_id:
                    self.s.sendto('U {} to G {} info'.format(self.user_id.get(), group_id).encode(), self.ADDR)

    def more_group_record(self):
        print('0')
        if self.talk_to.get():
            print('1')
            group_id = re.match(r"\w{5,20}\(([0-9]{10})\)", self.selected_group).group(1)
            for group_text in self.groups:
                if group_text[0] == group_id:
                    print('2')
                    if group_text.text:
                        print('3')
                        earliest_id = group_text.text[0][0]
                        self.s.sendto('U {} to G {} m {}'.format(self.user_id.get(), group_id,  earliest_id).encode(), self.ADDR)
                    else:
                        self.s.sendto('U {} to G {} m '.format(self.user_id.get(), group_id).encode(), self.ADDR)

    def refresh_groups(self):
        self.groups.sort(key=lambda x: x[1])
        self.my_groups.delete(0, tk.END)
        fore_item = ''
        for item in self.groups:
            if item[0] != fore_item:
                 self.my_groups.insert(tk.END, '{}({})'.format(item[1], item[0]))
            fore_item = item[0]

    # self.friends.sort(key=lambda x: x[1])
    #     self.my_friends.delete(0, tk.END)
    #     fore_item = ''
    #     for item in self.friends:
    #         if item[0] != fore_item:
    #             self.my_friends.insert(tk.END, '{}({})'.format(item[1], item[0]))
    #         fore_item = item[0]  

    def login_out(self):
        self.s.sendto('U {} O'.format(self.user_id.get()).encode(), self.ADDR)
        os._exit(0)

    # 注册界面
    def register_toplevel(self):
        # self.login_register_button['relief'] = tk.FLAT
        self.toplevel.destroy()
        self.user_id = tk.StringVar()
        self.user_name = tk.StringVar()
        self.password = tk.StringVar()
        self.password_check = tk.StringVar()
        self.toplevel = tk.Toplevel()
        self.toplevel.wm_protocol("WM_DELETE_WINDOW", self.login_toplevel)
        self.toplevel.title("注册")
        sw = self.toplevel.winfo_screenwidth()
        sh = self.toplevel.winfo_screenheight()
        self.toplevel.anchor('center')
        self.alignstr = '+%d+%d' % (sw / 2, sh/ 2)
        self.toplevel.geometry(self.alignstr)
        tk.Label(self.toplevel).grid(row=0, stick=tk.W, pady=10, padx=10)
        tk.Label(self.toplevel, text='账  户: ').grid(row=1, column=0, sticky=tk.E, pady=10, padx=10)
        tk.Entry(self.toplevel, textvariable=self.user_id, validate='focusout', vcmd=self.id_check, invcmd=self.id_error,
                 width=25, highlightthickness=0).grid(row=1, column=1, columnspan=3, stick=tk.W)
        tk.Label(self.toplevel, text='由12位数字组成', fg='grey').grid(row=1, column=4, stick=tk.W, padx=10)
        tk.Label(self.toplevel, text='昵  称: ').grid(row=2, column=0, sticky=tk.E, pady=10, padx=10)
        tk.Entry(self.toplevel, textvariable=self.user_name, validate='focusout', vcmd=self.name_check, invcmd=self.name_error,
                 width=25, highlightthickness=0).grid(row=2, column=1, columnspan=3, stick=tk.W)
        tk.Label(self.toplevel, text='由5-20位文字符号组成', fg='grey').grid(row=2, column=4, stick=tk.W, padx=10)
        tk.Label(self.toplevel, text='密  码: ').grid(row=3, column=0, sticky=tk.E, pady=10, padx=10)
        tk.Entry(self.toplevel, textvariable=self.password, validate='focusout', vcmd=self.passwd_check, invcmd=self.passwd_error,
                 width=25, show='*', highlightthickness=0).grid(row=3, column=1, columnspan=3, stick=tk.W)
        tk.Label(self.toplevel, text='由6-16位大小写字母和数字组成', fg='grey').grid(row=3, column=4, stick=tk.W, padx=10)
        tk.Label(self.toplevel, text='确认密码: ').grid(row=4, column=0, sticky=tk.E, pady=10, padx=10)
        tk.Entry(self.toplevel, textvariable=self.password_check, validate='focusout', vcmd=self.passwd_eq_check, invcmd=self.passwd_eq_error,
                 width=25, show='*', highlightthickness=0).grid(row=4, column=1, columnspan=3, stick=tk.W)
        tk.Button(self.toplevel, text='确定', command=self.register, relief=tk.FLAT, bd=0, activeforeground='#09BB07', bg='#40DD40', cursor='hand2').grid(row=5, column=0, columnspan=2, pady=20, padx=10)
        tk.Button(self.toplevel, text="取消", command=self.login_toplevel, relief=tk.FLAT, bd=0, activeforeground='#09BB07', bg='#40DD40', cursor='hand2').grid(row=5, column=2, columnspan=2, pady=10, padx=10, stick=tk.E)



    def id_check(self):
        id_result = re.match(r"^[0-9]{12}$", self.user_id.get())
        if id_result:
            return True
        else:
            return False

    def name_check(self):
        name_result = re.match(r"^\w{5,20}$", self.user_name.get())
        if name_result:
            return True
        else:
            return False

    def passwd_check(self):
        passwd_result = re.match(r"^[0-9A-Za-z]{6,16}$", self.password.get())
        if passwd_result:
            return True
        else:
            return False

    def passwd_eq_check(self):
        if self.password.get() == self.password_check.get():
            return True
        else:
            return False

    def id_error(self):
        mb.showerror('账户错误', '账户由12位数字组成!')

    def name_error(self):
        mb.showerror('昵称错误', '昵称由5-20位文字符号组成!')

    def passwd_error(self):
        mb.showerror('密码错误', '密码由6-16位大小写字母和数字组成!')

    def passwd_eq_error(self):
        mb.showerror('密码错误', '两次输入的密码不一样!')

    def register(self):
        if not (self.id_check() and self.name_check() and self.passwd_check() and self.passwd_eq_check()):
            mb.showerror('注册失败', '输入错误!          ')
            return
        self.msg = 'U {} {} {} R'.format(self.user_id.get(), self.user_name.get(), self.password.get()).encode()
        self.s.sendto(self.msg, self.ADDR)

    def refuse_u_as_friend(self, the_id):
        self.refuse_u_as_friend_toplevel = tk.Toplevel()
        self.refuse_u_as_friend_toplevel.title('系统消息')
        sw = self.refuse_u_as_friend_toplevel.winfo_screenwidth()
        sh = self.refuse_u_as_friend_toplevel.winfo_screenheight()
        pot = '+%d+%d' % (sw / 2, sh/ 2)
        self.refuse_u_as_friend_toplevel.geometry(pot)
        msg = 'id号为{}的用户拒绝添加您为好友...并向你扔了一个婷姐.'.format(the_id)
        tk.Label(self.refuse_u_as_friend_toplevel, text=msg, width=60, height=3).grid(row=0, column=0, columnspan=2)
        self.ting = tk.PhotoImage(file='ting.gif')
        tk.Label(self.refuse_u_as_friend_toplevel, image=self.ting).grid(row=1, column=0, columnspan=2, sticky=tk.S, pady=5)
        self.refuse_u_as_friend_toplevel.anchor('center')


    def refuse_u_as_member(self, group_id):
        self.refuse_u_as_member_toplevel = tk.Toplevel()
        self.refuse_u_as_member_toplevel.title('系统消息')
        sw = self.refuse_u_as_member_toplevel.winfo_screenwidth()
        sh = self.refuse_u_as_member_toplevel.winfo_screenheight()
        pot = '+%d+%d' % (sw / 2, sh/ 2)
        self.refuse_u_as_member_toplevel.geometry(pot)
        msg = 'id号为{}的群拒绝添加您为成员...\n他们祝您齐天大剩, 并向你扔了一个婷姐.'.format(group_id)
        tk.Label(self.refuse_u_as_member_toplevel, text=msg, justify=tk.LEFT, width=60, height=3).grid(row=0, column=0, columnspan=2)
        self.ting = tk.PhotoImage(file='ting.gif')
        tk.Label(self.refuse_u_as_member_toplevel, image=self.ting).grid(row=1, column=0, columnspan=2, sticky=tk.S, pady=5)
        self.refuse_u_as_member_toplevel.anchor('center')


    def agreed_u_as_friend(self, the_id):
        self.agreed_u_as_friend_toplevel = tk.Toplevel()
        self.agreed_u_as_friend_toplevel.title('系统消息')
        sw = self.agreed_u_as_friend_toplevel.winfo_screenwidth()
        sh = self.agreed_u_as_friend_toplevel.winfo_screenheight()
        pot = '+%d+%d' % (sw / 2, sh/ 2)
        self.agreed_u_as_friend_toplevel.geometry(pot)
        msg = 'id号为{}的用户已同意添加您为好友, 来吧, 互相伤害吧!'.format(the_id)
        tk.Label(self.agreed_u_as_friend_toplevel, text=msg, width=60, height=3).grid(row=0, column=0, columnspan=2)
        self.agreed_u_as_friend_toplevel.anchor('center')

    def agreed_u_as_member(self, the_id):
        self.agreed_u_as_member_toplevel = tk.Toplevel()
        self.agreed_u_as_member_toplevel.title('系统消息')
        sw = self.agreed_u_as_member_toplevel.winfo_screenwidth()
        sh = self.agreed_u_as_member_toplevel.winfo_screenheight()
        pot = '+%d+%d' % (sw / 2, sh/ 2)
        self.agreed_u_as_member_toplevel.geometry(pot)
        msg = 'id号为{}的群聊已同意添加您为成员, 来吧, 看看情侣们是怎样秀恩爱的吧!'.format(the_id)
        tk.Label(self.agreed_u_as_member_toplevel, text=msg, width=65, height=3).grid(row=0, column=0, columnspan=2)
        self.agreed_u_as_member_toplevel.anchor('center')

    def more_group_info_interface(self, group_id, tup):
        self.more_group_info_toplevel = tk.Toplevel()
        self.more_group_info_toplevel.title('群聊({})信息'.format(group_id))
        sw = self.more_group_info_toplevel.winfo_screenwidth()
        sh = self.more_group_info_toplevel.winfo_screenheight()
        pot = '+%d+%d' % (sw / 2, sh/ 2)
        self.more_group_info_toplevel.geometry(pot)
        tk.Label(self.more_group_info_toplevel, text='群主', justify=tk.LEFT, anchor=tk.W).grid(row=0, column=0, sticky=tk.W)
        self.owner_msg_frame = tk.Frame(self.more_group_info_toplevel)
        self.owner_msg_frame.grid(row=1, column=0)
        self.owner_msg = tk.Listbox(self.owner_msg_frame, selectmode = tk.BROWSE, height=1, width=40, bg='#EEEAE8', highlightthickness=0, bd=0)
        sbx = tk.Scrollbar(self.owner_msg_frame, orient=tk.HORIZONTAL, command=self.owner_msg.xview, troughcolor='#EEEAE8', width=8,  bg='#EEEAE8', activebackground="#D2D2D2", bd=0)
        sbx.grid(row=1, sticky=tk.E+tk.W)
        self.owner_msg['xscrollcommand'] = sbx.set
        self.owner_msg.grid(row=0, column=0)
        self.owner_msg.insert(tk.END, '{}({})'.format(tup[0][1], tup[0][0]))
        tk.Label(self.more_group_info_toplevel, text='群成员', justify=tk.LEFT, anchor=tk.W).grid(row=2, column=0, sticky=tk.W)
        self.members_msg_frame = tk.Frame(self.more_group_info_toplevel)
        self.members_msg_frame.grid(row=3, column=0)
        self.members_msg = tk.Listbox(self.members_msg_frame, selectmode = tk.BROWSE, height=5, width=40, bg='#EEEAE8', highlightthickness=0, bd=0)
        sby = tk.Scrollbar(self.members_msg_frame, orient=tk.VERTICAL, command=self.members_msg.yview, troughcolor='#EEEAE8', width=8,  bg='#EEEAE8', activebackground="#D2D2D2", bd=0)
        sby.grid(column=1, sticky=tk.N+tk.S)
        self.members_msg['yscrollcommand'] = sby.set
        sbx = tk.Scrollbar(self.members_msg_frame, orient=tk.HORIZONTAL, command=self.members_msg.xview, troughcolor='#EEEAE8', width=8,  bg='#EEEAE8', activebackground="#D2D2D2", bd=0)
        sbx.grid(row=1, sticky=tk.E+tk.W)
        self.members_msg['xscrollcommand'] = sbx.set
        self.members_msg.grid(row=0, column=0)
        members_msg_list = list(tup[1])
        members_msg_list.sort(key=lambda x: x[1])
        for member_msg in members_msg_list:
            self.members_msg.insert(tk.END, '{}({})'.format(member_msg[1], member_msg[0]))

    def send_the_file(self, friend_id, file_name, file_size, path, addr, q):
        # self.quit()
        self.send_the_file_toplevel = tk.Toplevel()
        # self.send_the_file_toplevel.wm_protocol("WM_DELETE_WINDOW", self.stop)
        self.send_the_file_toplevel.title('正在上传文件')

        self.file_size = file_size
        self.addr = addr
        self.already_send_size = 0
        print('?')
        self.speed_of_progress = tk.StringVar()
        self.speed = tk.StringVar()
        self.percent_of_progress = tk.StringVar()
        print('这里')
        if self.file_size > 10 ** 6:
            self.speed_of_progress.set('{}B/{:>.3f}M'.format(self.already_send_size, self.file_size / 10 ** 6))
        elif self.file_size > 10 ** 3:
            self.speed_of_progress.set('{}B/{:>.3f}K'.format(self.already_send_size, self.file_size / 10 ** 3))
        else:  
            self.speed_of_progress.set('{}B/{}B'.format(self.already_send_size, self.file_size))
        self.percent_of_progress.set('{:2}%'.format(self.already_send_size * 100 / self.file_size))
        self.speed.set('{}B/s'.format(self.already_send_size))
        tk.Label(self.send_the_file_toplevel, text='正在传文件给好友{}'.format(friend_id), justify=tk.LEFT).grid(row=0, column=0, sticky=tk.W)
        tk.Label(self.send_the_file_toplevel, text='进度:', justify=tk.LEFT).grid(row=1, column=0, sticky=tk.W)
        self.percent_of_progress_label = tk.Label(self.send_the_file_toplevel, textvariable=self.percent_of_progress, justify=tk.RIGHT)
        self.percent_of_progress_label.grid(row=2, column=0, sticky=tk.E)
        self.speed_label = tk.Label(self.send_the_file_toplevel, textvariable=self.speed, justify=tk.RIGHT)
        self.speed_label.grid(row=3, column=0, sticky=tk.E)
        self.speed_of_progress_label = tk.Label(self.send_the_file_toplevel, textvariable=self.speed_of_progress, justify=tk.RIGHT)
        self.speed_of_progress_label.grid(row=4, column=0, sticky=tk.E)
        self.progress_bar = tk.Text(self.send_the_file_toplevel, bd=0, height=1, width=50, state='disable')
        self.progress_bar.grid(row=5, column=0)
        th = threading.Thread(target=self.speed_of_progress_update, args=(file_name, friend_id, q))
        print('h')
        th.setDaemon(True)
        th.start()

    def send_the_file_to_group(self, group_id, file_name, file_size, path, addr, q):
        # self.quit()
        self.group_send_the_file_to_group_toplevel = tk.Toplevel()
        # self.send_the_file_to_group_toplevel.wm_protocol("WM_DELETE_WINDOW", self.stop)
        self.group_send_the_file_to_group_toplevel.title('正在上传文件')

        self.group_file_size = file_size
        self.group_addr = addr
        self.group_already_send_size = 0
        print('?')
        self.group_speed_of_progress = tk.StringVar()
        self.group_speed = tk.StringVar()
        self.group_percent_of_progress = tk.StringVar()
        print('这里')
        if self.group_file_size > 10 ** 6:
            self.group_speed_of_progress.set('{}B/{:>.3f}M'.format(self.group_already_send_size, self.group_file_size / 10 ** 6))
        elif self.group_file_size > 10 ** 3:
            self.group_speed_of_progress.set('{}B/{:>.3f}K'.format(self.group_already_send_size, self.group_file_size / 10 ** 3))
        else:
            self.group_speed_of_progress.set('{}B/{}B'.format(self.group_already_send_size, self.group_file_size))
        self.group_percent_of_progress.set('{:2}%'.format(self.group_already_send_size * 100 / self.group_file_size))
        self.group_speed.set('{}B/s'.format(self.group_already_send_size))
        tk.Label(self.group_send_the_file_to_group_toplevel, text='正在传文件给好友{}'.format(group_id), justify=tk.LEFT).grid(row=0, column=0, sticky=tk.W)
        tk.Label(self.group_send_the_file_to_group_toplevel, text='进度:', justify=tk.LEFT).grid(row=1, column=0, sticky=tk.W)
        self.group_percent_of_progress_label = tk.Label(self.group_send_the_file_to_group_toplevel, textvariable=self.group_percent_of_progress, justify=tk.RIGHT)
        self.group_percent_of_progress_label.grid(row=2, column=0, sticky=tk.E)
        self.group_speed_label = tk.Label(self.group_send_the_file_to_group_toplevel, textvariable=self.group_speed, justify=tk.RIGHT)
        self.group_speed_label.grid(row=3, column=0, sticky=tk.E)
        self.group_speed_of_progress_label = tk.Label(self.group_send_the_file_to_group_toplevel, textvariable=self.group_speed_of_progress, justify=tk.RIGHT)
        self.group_speed_of_progress_label.grid(row=4, column=0, sticky=tk.E)
        self.group_progress_bar = tk.Text(self.group_send_the_file_to_group_toplevel, bd=0, height=1, width=50, state='disable')
        self.group_progress_bar.grid(row=5, column=0)
        th = threading.Thread(target=self.group_speed_of_progress_update, args=(file_name, group_id, q))
        print('h')
        th.setDaemon(True)
        th.start()

    def down_load_the_file(self, friend_id, file_name, file_size, path, addr, q):
        self.down_load_the_file_toplevel = tk.Toplevel()
        # self.down_load_the_file_toplevel.wm_protocol("WM_DELETE_WINDOW", self.stop)
        self.down_load_the_file_toplevel.title('正在下载文件')
        self.file_size = eval(file_size)
        if not self.file_size:
            mb.showwarning('文件传输', '文件为空')
            return
        self.addr = addr
        self.already_down_load_size = 0
        print('?')
        self.speed_of_progress = tk.StringVar()
        self.speed = tk.StringVar()
        self.percent_of_progress = tk.StringVar()
        print('这里')
        if self.file_size > 10 ** 6:
            self.speed_of_progress.set('{}B/{:>.3f}M'.format(self.already_down_load_size, self.file_size / 10 ** 6))
        elif self.file_size > 10 ** 3:
            self.speed_of_progress.set('{}B/{:>.3f}K'.format(self.already_down_load_size, self.file_size / 10 ** 3))
        else:
            self.speed_of_progress.set('{}B/{}B'.format(self.already_down_load_size, self.file_size))
        self.percent_of_progress.set('{:2}%'.format(self.already_down_load_size * 100 / self.file_size))
        self.speed.set('{}B/s'.format(self.already_down_load_size))
        tk.Label(self.down_load_the_file_toplevel, text='正在从好友{}界面下载文件'.format(friend_id), justify=tk.LEFT).grid(row=0, column=0, sticky=tk.W)
        tk.Label(self.down_load_the_file_toplevel, text='进度:', justify=tk.LEFT).grid(row=1, column=0, sticky=tk.W)
        self.percent_of_progress_label = tk.Label(self.down_load_the_file_toplevel, textvariable=self.percent_of_progress, justify=tk.RIGHT)
        self.percent_of_progress_label.grid(row=2, column=0, sticky=tk.E)
        self.speed_label = tk.Label(self.down_load_the_file_toplevel, textvariable=self.speed, justify=tk.RIGHT)
        self.speed_label.grid(row=3, column=0, sticky=tk.E)
        self.speed_of_progress_label = tk.Label(self.down_load_the_file_toplevel, textvariable=self.speed_of_progress, justify=tk.RIGHT)
        self.speed_of_progress_label.grid(row=4, column=0, sticky=tk.E)
        self.progress_bar = tk.Text(self.down_load_the_file_toplevel, bd=0, height=1, width=50, state='disable')
        self.progress_bar.grid(row=5, column=0)
        print('gc fiei')
        th = threading.Thread(target=self.speed_of_down_load_update, args=(file_name, friend_id, q))
        print('h')
        th.setDaemon(True)
        th.start()

    def group_down_load_the_file(self, group_id, file_name, file_size, path, addr, q):
        self.group_down_load_the_file_toplevel = tk.Toplevel()
        # self.group_down_load_the_file_toplevel.wm_protocol("WM_DELETE_WINDOW", self.group_stop)
        self.group_down_load_the_file_toplevel.title('正在下载文件')
        self.group_file_size = eval(file_size)
        if not self.group_file_size:
            mb.showwarning('文件传输', '文件为空')
            return
        self.group_addr = addr
        self.group_already_down_load_size = 0
        print('?')
        self.group_speed_of_progress = tk.StringVar()
        self.group_speed = tk.StringVar()
        self.group_percent_of_progress = tk.StringVar()
        print('这里')
        if self.group_file_size > 10 ** 6:
            self.group_speed_of_progress.set('{}B/{:>.3f}M'.format(self.group_already_down_load_size, self.group_file_size / 10 ** 6))
        elif self.group_file_size > 10 ** 3:
            self.group_speed_of_progress.set('{}B/{:>.3f}K'.format(self.group_already_down_load_size, self.group_file_size / 10 ** 3))
        else:    
            self.group_speed_of_progress.set('{}B/{}B'.format(self.group_already_down_load_size, self.group_file_size))
        self.group_percent_of_progress.set('{:2}%'.format(self.group_already_down_load_size * 100 / self.group_file_size))
        self.group_speed.set('{}B/s'.format(self.group_already_down_load_size))
        tk.Label(self.group_down_load_the_file_toplevel, text='正在从群{}中下载文件'.format(group_id), justify=tk.LEFT).grid(row=0, column=0, sticky=tk.W)
        tk.Label(self.group_down_load_the_file_toplevel, text='进度:', justify=tk.LEFT).grid(row=1, column=0, sticky=tk.W)
        self.group_percent_of_progress_label = tk.Label(self.group_down_load_the_file_toplevel, textvariable=self.group_percent_of_progress, justify=tk.RIGHT)
        self.group_percent_of_progress_label.grid(row=2, column=0, sticky=tk.E)
        self.group_speed_label = tk.Label(self.group_down_load_the_file_toplevel, textvariable=self.group_speed, justify=tk.RIGHT)
        self.group_speed_label.grid(row=3, column=0, sticky=tk.E)
        self.group_speed_of_progress_label = tk.Label(self.group_down_load_the_file_toplevel, textvariable=self.group_speed_of_progress, justify=tk.RIGHT)
        self.group_speed_of_progress_label.grid(row=4, column=0, sticky=tk.E)
        self.group_progress_bar = tk.Text(self.group_down_load_the_file_toplevel, bd=0, height=1, width=50, state='disable')
        self.group_progress_bar.grid(row=5, column=0)
        print('gc fiei')
        th = threading.Thread(target=self.group_speed_of_down_load_update, args=(file_name, group_id, q))
        print('h')
        th.setDaemon(True)
        th.start()

    def speed_of_progress_update(self, file_name, friend_id, q):
        try:
            fore_size = 0
            while True:
                print('hehe')
                # while True:
                #     if q.full():
                print('拿前', q.qsize())
                fore_time = time.time()                              
                time.sleep(0.1)
                self.already_send_size = q.get(True)
                after_time = time.time()
                speed = (self.already_send_size - fore_size) / (after_time - fore_time)
                fore_size = self.already_send_size
                print('拿后', q.qsize())
                        # break
                print('get', self.already_send_size)
                if not self.file_size:
                    return
                n = self.already_send_size * 50 // self.file_size
                if self.file_size > 10 ** 6:
                    if self.already_send_size > 10 ** 6:
                        self.speed_of_progress.set('{:>.3f}M/{:>.3f}M'.format(self.already_send_size / 10 ** 6, self.file_size / 10 ** 6))
                    elif self.already_send_size > 10 ** 3:
                        self.speed_of_progress.set('{:>.3f}K/{:>.3f}M'.format(self.already_send_size / 10 ** 3, self.file_size / 10 ** 6))
                    else:
                        self.speed_of_progress.set('{}B/{:>.3f}M'.format(self.already_send_size, self.file_size / 10 ** 6))
                elif self.file_size > 10 ** 3:
                    if self.already_send_size > 10 ** 3:
                        self.speed_of_progress.set('{:>.3f}K/{:>.3f}K'.format(self.already_send_size / 10 ** 3, self.file_size / 10 ** 3))
                    else:
                        self.speed_of_progress.set('{}B/{:>.3f}K'.format(self.already_send_size, self.file_size / 10 ** 3))
                else:
                    self.speed_of_progress.set('{}B/{}B'.format(self.already_send_size, self.file_size))
                self.percent_of_progress.set('{:>.3f}%'.format(self.already_send_size * 100 / self.file_size))
                if speed > 10**5:
                    self.speed.set('{:>.1f}M/s'.format(speed / 10 ** 6))
                elif speed > 10 ** 2:
                    self.speed.set('{:>.1f}K/s'.format(speed / 10 ** 3))
                else:
                    self.speed.set('{:>.1f}B/s'.format(speed))
                self.progress_bar['state'] = 'normal'
                self.progress_bar.delete('0.0', 'end')
                self.progress_bar.insert(tk.END, ' ' * n)
                self.progress_bar.tag_add('tag1', '1.0', '1.{}'.format(n))
                self.progress_bar.tag_config('tag1', background='green')
                self.progress_bar['state'] = 'disable' 
                if self.already_send_size == self.file_size:
                    mb.showinfo('文件传输完毕', '已将文件{}传输给好友{}'.format(file_name, friend_id))
                    break
        except BaseException as e:
            print('退出', e)

    def group_speed_of_progress_update(self, file_name, group_id, q):
        try:
            fore_size = 0
            while True:
                print('hehe')
                # while True:
                #     if q.full():
                print('拿前', q.qsize())
                fore_time = time.time()
                time.sleep(0.1)
                self.group_already_send_size = q.get(True)
                after_time = time.time()
                speed = (self.group_already_send_size - fore_size) / (after_time - fore_time)
                fore_size = self.group_already_send_size
                print('拿后', q.qsize())
                        # break
                print('get', self.group_already_send_size)
                if not self.group_file_size:
                    return
                n = self.group_already_send_size * 50 // self.group_file_size
                if self.group_file_size > 10 ** 6:
                    if self.group_already_send_size > 10 ** 6:
                        self.group_speed_of_progress.set('{:>.3f}M/{:>.3f}M'.format(self.group_already_send_size / 10 ** 6, self.group_file_size / 10 ** 6))
                    elif self.group_already_send_size > 10 ** 3:
                        self.group_speed_of_progress.set('{:>.3f}K/{:>.3f}M'.format(self.group_already_send_size / 10 ** 3, self.group_file_size / 10 ** 6))
                    else:
                        self.group_speed_of_progress.set('{}B/{:>.3f}M'.format(self.group_already_send_size, self.group_file_size / 10 ** 6))
                elif self.group_file_size > 10 ** 3:
                    if self.group_already_send_size > 10 ** 3:
                        self.group_speed_of_progress.set('{:>.3f}K/{:>.3f}K'.format(self.group_already_send_size / 10 ** 3, self.group_file_size / 10 ** 3))
                    else:
                        self.group_speed_of_progress.set('{}B/{:>.3f}K'.format(self.group_already_send_size, self.group_file_size / 10 ** 3))
                else:
                    self.group_speed_of_progress.set('{}B/{}B'.format(self.group_already_send_size, self.group_file_size))
                self.group_percent_of_progress.set('{:>.3f}%'.format(self.group_already_send_size * 100 / self.group_file_size))
                if speed > 10**5:
                    self.group_speed.set('{:>.1f}M/s'.format(speed / 10 ** 6))
                elif speed > 10 ** 2:
                    self.group_speed.set('{:>.1f}K/s'.format(speed / 10 ** 3))
                else:
                    self.group_speed.set('{:>.1f}B/s'.format(speed))
                self.group_progress_bar['state'] = 'normal'
                self.group_progress_bar.delete('0.0', 'end')
                self.group_progress_bar.insert(tk.END, ' ' * n)
                self.group_progress_bar.tag_add('tag1', '1.0', '1.{}'.format(n))
                self.group_progress_bar.tag_config('tag1', background='green')
                self.group_progress_bar['state'] = 'disable' 
                if self.group_already_send_size == self.group_file_size:
                    mb.showinfo('文件传输完毕', '已将文件{}传输给群{}'.format(file_name, group_id))
                    break
        except BaseException as e:
            print('退出', e)

    def speed_of_down_load_update(self, file_name, friend_id, q):
        try:
            fore_size = 0
            self.already_down_load_size = 0
            print('是这吗')
            while True:
                print('hehe')
                # while True:
                #     if q.full():
                print('我拿前', q.qsize(), fore_size)
                fore_time = time.time()
                time.sleep(0.1)
                self.already_down_load_size = q.get(True)
                after_time = time.time()
                speed = (self.already_down_load_size - fore_size) / (after_time - fore_time)
                fore_size = self.already_down_load_size
                print('我拿后', q.qsize(), fore_size)
                        # break
                print('get', self.already_down_load_size)
                # self.speed_of_down_load_update = tk.StringVar()
                # self.already_down_load_size = 0
                if not self.file_size:
                    return
                n = self.already_down_load_size * 50 // self.file_size
                if self.file_size > 10 ** 6:
                    if self.already_down_load_size > 10 ** 6:
                        self.speed_of_progress.set('{:>.3f}M/{:>.3f}M'.format(self.already_down_load_size / 10 ** 6, self.file_size / 10 ** 6))
                    elif self.already_down_load_size > 10 ** 3:
                        self.speed_of_progress.set('{:>.3f}K/{:>.3f}M'.format(self.already_down_load_size / 10 ** 3, self.file_size / 10 ** 6))
                    else:
                        self.speed_of_progress.set('{}B/{:>.3f}M'.format(self.already_down_load_size, self.file_size / 10 ** 6))
                elif self.file_size > 10 ** 3:
                    if self.already_down_load_size > 10 ** 3:
                        self.speed_of_progress.set('{:>.3f}K/{:>.3f}K'.format(self.already_down_load_size / 10 ** 3, self.file_size / 10 ** 3))
                    else:
                        self.speed_of_progress.set('{}B/{:>.3f}K'.format(self.already_down_load_size, self.file_size / 10 ** 3))
                else:
                    self.speed_of_progress.set('{}B/{}B'.format(self.already_down_load_size, self.file_size))
                self.percent_of_progress.set('{:>.3f}%'.format(self.already_down_load_size * 100 / self.file_size))
                if speed > 10**5:
                    self.speed.set('{:>.1f}M/s'.format(speed / 10 ** 6))
                elif speed > 10 ** 2:
                    self.speed.set('{:>.1f}K/s'.format(speed / 10 ** 3))
                else:
                    self.speed.set('{:>.1f}B/s'.format(speed))
                self.progress_bar['state'] = 'normal'
                self.progress_bar.delete('0.0', 'end')
                self.progress_bar.insert(tk.END, ' ' * n)
                self.progress_bar.tag_add('tag1', '1.0', '1.{}'.format(n))
                self.progress_bar.tag_config('tag1', background='green')
                self.progress_bar['state'] = 'disable' 
                if self.already_down_load_size == self.file_size:
                    mb.showinfo('文件下载完毕', '已将文件{0}从好友{1}界面下载完毕, 相对路径为:files/U{2}/U{1}/{0}'.format(file_name, friend_id, self.user_id.get()))
                    break
        except BaseException as e:
            print('退出', e)

    def group_speed_of_down_load_update(self, file_name, group_id, q):
        try:
            fore_size = 0
            self.group_already_down_load_size = 0
            print('是这吗')
            while True:
                print('hehe')
                # while True:
                #     if q.full():
                print('我拿前', q.qsize())
                fore_time = time.time()
                time.sleep(0.1)
                self.group_already_down_load_size = q.get(True)
                after_time = time.time()
                speed = (self.group_already_down_load_size - fore_size) / (after_time - fore_time)
                fore_size = self.group_already_down_load_size
                print('我拿后', q.qsize())
                        # break
                print('get', self.group_already_down_load_size)
                # self.group_speed_of_down_load_update = tk.StringVar()
                # self.group_already_down_load_size = 0
                if not self.group_file_size:
                    return
                n = self.group_already_down_load_size * 50 // self.group_file_size
                if self.group_file_size > 10 ** 6:
                    if self.group_already_down_load_size > 10 ** 6:
                        self.group_speed_of_progress.set('{:>.3f}M/{:>.3f}M'.format(self.group_already_down_load_size / 10 ** 6, self.group_file_size / 10 ** 6))
                    elif self.group_already_down_load_size > 10 ** 3:
                        self.group_speed_of_progress.set('{:>.3f}K/{:>.3f}M'.format(self.group_already_down_load_size / 10 ** 3, self.group_file_size / 10 ** 6))
                    else:
                        self.group_speed_of_progress.set('{}B/{:>.3f}M'.format(self.group_already_down_load_size, self.group_file_size / 10 ** 6))
                elif self.group_file_size > 10 ** 3:
                    if self.group_already_down_load_size > 10 ** 3:
                        self.group_speed_of_progress.set('{:>.3f}K/{:>.3f}K'.format(self.group_already_down_load_size / 10 ** 3, self.group_file_size / 10 ** 3))
                    else:
                        self.group_speed_of_progress.set('{}B/{:>.3f}K'.format(self.group_already_down_load_size, self.group_file_size / 10 ** 3))
                else:
                    self.group_speed_of_progress.set('{}B/{}B'.format(self.group_already_down_load_size, self.group_file_size))
                self.group_percent_of_progress.set('{:>.3f}%'.format(self.group_already_down_load_size * 100 / self.group_file_size))
                if speed > 10**5:
                    self.group_speed.set('{:>.1f}M/s'.format(speed / 10 ** 6))
                elif speed > 10 ** 2:
                    self.group_speed.set('{:>.1f}K/s'.format(speed / 10 ** 3))
                else:
                    self.group_speed.set('{:>.1f}B/s'.format(speed))
                self.group_progress_bar['state'] = 'normal'
                self.group_progress_bar.delete('0.0', 'end')
                self.group_progress_bar.insert(tk.END, ' ' * n)
                self.group_progress_bar.tag_add('tag1', '1.0', '1.{}'.format(n))
                self.group_progress_bar.tag_config('tag1', background='green')
                self.group_progress_bar['state'] = 'disable' 
                if self.group_already_down_load_size == self.group_file_size:
                    mb.showinfo('文件下载完毕', '已将文件{0}从群{1}中下载完毕, 相对路径为:files/U{2}/G{1}/{0}'.format(file_name, group_id, self.user_id.get()))
                    break
        except BaseException as e:
            print('退出', e)

    def start(self, friend_id, file_name, file_size, path, addr, q):
        try:
            fore_size = 0
            self.already_send_size = 0
            self.s = socket(AF_INET, SOCK_STREAM)
            print('到这了')
            print(addr)
            self.s.connect(addr)
            self.s.recv(1024)
            with open (path, 'rb') as f:
                while True:
                    data = f.read(1024)
                    try:
                        self.s.send(data)
                    except Exception as e:
                        print('传输完毕', e)
                    self.already_send_size += len(data)
                    try:
                        if fore_size != self.already_send_size:
                            q.put(self.already_send_size, False)
                            fore_size = self.already_send_size
                            print('put', self.already_send_size)
                    except Exception as e:
                        print('此时队列不为空', e)
                        continue
                            # break
                    # self.speed_of_progress.set('{}B/{}B'.format(self.already_send_size, file_size))
                    print('end')
                    # self.send_the_file_toplevel = tk.Toplevel()
                    # self.send_the_file_toplevel.wm_protocol("WM_DELETE_WINDOW", self.leave)
                    # self.send_the_file_toplevel.title('文件传输完毕')
                    # tk.Label(self.send_the_file_toplevel, text='已将文件{}传输给好友{}'.format(file_name, friend_id)).grid(row=0, column=0)
                    # tk.Button(self.send_the_file_toplevel, text='确定', command=self.leave).grid(row=1, column=0)
                    if not data:
                        print('最后', q.qsize())
                        while True:
                            time.sleep(1)
                            if not q.qsize():
                                print('退出了')
                                os._exit(0)
            
            
        except BaseException as e:
            print('退出', e)

    def group_start(self, group_id, file_name, file_size, path, addr, q):
        try:
            fore_size = 0
            self.group_already_send_size = 0
            self.s = socket(AF_INET, SOCK_STREAM)
            print('到这了')
            print(addr)
            self.s.connect(addr)
            self.s.recv(1024)
            with open (path, 'rb') as f:
                while True:
                    data = f.read(1024)
                    try:
                        self.s.send(data)
                    except Exception as e:
                        print('传输完毕', e)
                    self.group_already_send_size += len(data)
                    print('put', self.group_already_send_size)
                    try:
                        if fore_size != self.group_already_send_size:
                            q.put(self.group_already_send_size, False)
                            fore_size = self.group_already_send_size
                    except Exception as e:
                        print('队列不为空', e)
                        continue
                            # break
                    # self.speed_of_progress.set('{}B/{}B'.format(self.already_send_size, file_size))
                    print('end')
                    # self.send_the_file_toplevel = tk.Toplevel()
                    # self.send_the_file_toplevel.wm_protocol("WM_DELETE_WINDOW", self.leave)
                    # self.send_the_file_toplevel.title('文件传输完毕')
                    # tk.Label(self.send_the_file_toplevel, text='已将文件{}传输给好友{}'.format(file_name, friend_id)).grid(row=0, column=0)
                    # tk.Button(self.send_the_file_toplevel, text='确定', command=self.leave).grid(row=1, column=0)
                    if not data:
                        print('最后', q.qsize())
                        while True:
                            time.sleep(1)
                            if not q.qsize():
                                print('退出了')
                                os._exit(0)
        except BaseException as e:
            os._exit(0)
            print('退出', e)

    def down_load(self, friend_id, file_name, file_size, path, addr, q):
        try:
            fore_size = 0
            self.s = socket(AF_INET, SOCK_STREAM)
            print('到这了')
            print(addr)
            self.s.connect(addr)
            with open (path, 'wb') as f:
                while True:
                    try:
                        data = self.s.recv(10240)
                        f.write(data)
                    except Exception as e:
                        print('传输完毕', e)
                    self.already_down_load_size += len(data)
                    print('put', self.already_down_load_size)
                    try:
                        if fore_size != self.already_down_load_size:
                            q.put(self.already_down_load_size, False)
                            fore_size = self.already_down_load_size
                    except Exception as e:
                        print('队列不为空', e)
                        time.sleep(0.1)
                        continue
                            # break
                    # self.speed_of_progress.set('{}B/{}B'.format(self.already_send_size, file_size))
                    print('end')
                    # self.send_the_file_toplevel = tk.Toplevel()
                    # self.send_the_file_toplevel.wm_protocol("WM_DELETE_WINDOW", self.leave)
                    # self.send_the_file_toplevel.title('文件传输完毕')
                    # tk.Label(self.send_the_file_toplevel, text='已将文件{}传输给好友{}'.format(file_name, friend_id)).grid(row=0, column=0)
                    # tk.Button(self.send_the_file_toplevel, text='确定', command=self.leave).grid(row=1, column=0)
                    if not data:
                        print('最后', q.qsize())
                        while True:
                            print('还没退出')
                            time.sleep(1)
                            if not q.qsize():
                                break
                        break
            print('退出了')
            os._exit(0)
        except BaseException as e:
            print('退出', e)

    def group_down_load(self, group_id, file_name, file_size, path, addr, q):
        try:
            fore_size = 0
            self.s = socket(AF_INET, SOCK_STREAM)
            print('到这了')
            print(addr)
            self.s.connect(addr)
            with open (path, 'wb') as f:
                while True:
                    try:
                        data = self.s.recv(10240)
                        f.write(data)
                    except Exception as e:
                        print('传输完毕', e)
                    self.group_already_down_load_size += len(data)
                    print('put', self.group_already_down_load_size)
                    try:
                        if fore_size != self.group_already_down_load_size:
                            q.put(self.group_already_down_load_size, False)
                            fore_size = self.group_already_down_load_size
                    except Exception as e:
                        print('队列不为空', e)
                        time.sleep(0.1)
                        continue
                            # break
                    # self.speed_of_progress.set('{}B/{}B'.format(self.already_send_size, file_size))
                    print('end')
                    # self.send_the_file_toplevel = tk.Toplevel()
                    # self.send_the_file_toplevel.wm_protocol("WM_DELETE_WINDOW", self.leave)
                    # self.send_the_file_toplevel.title('文件传输完毕')
                    # tk.Label(self.send_the_file_toplevel, text='已将文件{}传输给好友{}'.format(file_name, friend_id)).grid(row=0, column=0)
                    # tk.Button(self.send_the_file_toplevel, text='确定', command=self.leave).grid(row=1, column=0)
                    if not data:
                        print('最后', q.qsize())
                        while True:
                            print('还没退出')
                            time.sleep(1)
                            if not q.qsize():
                                break
                        break
            print('退出了')
            os._exit(0)
        except BaseException as e:
            print('退出', e)


    def message_recv(self):
        while True:
            print('there')
            data, addr = self.s.recvfrom(4096)
            print(data.decode())
            if data.decode() == "user existed":
                mb.showerror('用户已存在', '该账号已存在!')
                
            elif data.decode() == "successfully registered":
                mb.showinfo('注册成功', '已注册成功, 开始登录吧!')
                self.login_toplevel()
                
            elif data.decode() == 'remote login':
                mb.showwarning('异地登录', '您的账号在异地登录!')
                self.toplevel.destroy()
                self.login_toplevel()
                
            elif data.decode() == "user not exists":
                mb.showerror('用户不存在', '该账号不存在!')
                
            elif data.decode() == 'passwd error':
                mb.showerror('密码错误', '密码输入错误!   ')
                
            elif data.decode() == "group existed":
                mb.showwarning('群消息', '该群已存在')
                
            elif data.decode() == 'find user not exists':
                mb.showerror('用户不存在', '所查找用户账号不存在!')
                
            elif data.decode() == 'find group not exists':
                mb.showerror('群不存在', '所查找的群不存在!')
                
            elif re.match(r"^successfully logined (\w{5,20}) .*", data.decode()):
                self.user_name = re.match(r"^successfully logined (\w{5,20}) .*", data.decode()).group(1)
                self.login_button['state'] = 'active'
                self.main_user_interface(data.decode())
            elif re.match(r"^U([0-9]{12}) ADD$", data.decode()):
                Id = re.match(r"^U([0-9]{12}) ADD$", data.decode()).group(1)
                self.add_friend_message(Id)
                
            elif re.match(r"^U([0-9]{12}) to G([0-9]{10}) ADD$", data.decode()):
                result = re.match(r"^U([0-9]{12}) to G([0-9]{10}) ADD$", data.decode())
                from_id = result.group(1)
                group_id = result.group(2)
                self.add_group_message(from_id, group_id)
                
            elif re.match(r"^U([0-9]{12}) R U$", data.decode()):
                Id = re.match(r"^U([0-9]{12}) R U$", data.decode()).group(1)
                self.refuse_u_as_friend(Id)
                
            elif re.match(r"^G([0-9]{10}) R U$", data.decode()):
                Id = re.match(r"^G([0-9]{10}) R U$", data.decode()).group(1)
                print(Id)
                self.refuse_u_as_member(Id)
                
            elif re.match(r"^U([0-9]{12}) (\w{5,20}) A U (\d+) ([0-9]{12}) (\w{5,20}) (.*) (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)$", data.decode(), flags=re.S):
                result = re.match(r"^U([0-9]{12}) (\w{5,20}) A U (\d+) ([0-9]{12}) (\w{5,20}) (.*) (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)$", data.decode(), flags=re.S).groups()
                self.agreed_u_as_friend(result[0])
                self.friends.append(UserText(user=(result[0], result[1])))
                self.refresh_friends()
                self.refresh_friend_text(result[0], result[1], result[2], result[3], result[4], result[5], result[6])
                
            elif re.match(r"^G([0-9]{10}) (\w{5,20}) ([0-9]{12}) A U (\d+) ([0-9]{12}) (\w{5,20}) (.*) (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)$", data.decode(), flags=re.S):
                result = re.match(r"^G([0-9]{10}) (\w{5,20}) ([0-9]{12}) A U (\d+) ([0-9]{12}) (\w{5,20}) (.*) (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)$", data.decode(), flags=re.S).groups()
                self.agreed_u_as_member(result[0])
                self.groups.append(GroupText(group=(result[0], result[1], result[2])))
                self.refresh_groups()
                self.refresh_group_text(result[0], result[1], result[3], result[4], result[5], result[6], result[7])
                
            elif re.match(r"^U([0-9]{12}) (\w{5,20}) RT (\d+) ([0-9]{12}) (\w{5,20}) (.*) (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)$", data.decode(), flags=re.S):
                result = re.match(r"^U([0-9]{12}) (\w{5,20}) RT (\d+) ([0-9]{12}) (\w{5,20}) (.*) (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)$", data.decode(), flags=re.S).groups()
                self.friends.append(UserText(user=(result[0], result[1])))
                self.refresh_friends()
                self.refresh_friend_text(result[0], result[1], result[2], result[3], result[4], result[5], result[6])
                
            elif re.match(r"^U([0-9]{12}) AR$", data.decode()):
                result = re.match(r"^U([0-9]{12}) AR$", data.decode()).group(1)
                self.already_friend_info = mb.showinfo('系统消息', '你和{}已经是好友了'.format(result))
            elif re.match(r"^G([0-9]{10}) AR$", data.decode()):
                result = re.match(r"^G([0-9]{10}) AR$", data.decode()).group(1)
                mb.showinfo('系统消息', '您已是群({})的成员'.format(result))
                
            elif re.match(r"^U([0-9]{12}) not FR$", data.decode()):
                result = re.match(r"^U([0-9]{12}) not FR$", data.decode()).group(1)
                mb.showinfo('系统消息', '你和{}已经友尽, 注孤身!'.format(result))
                
            elif re.match(r"^G([0-9]{10}) not FR$", data.decode()):
                result = re.match(r"^G([0-9]{10}) not FR$", data.decode()).group(1)
                mb.showinfo('系统消息', '你已被群{}踢了, 好好过你的单身生活吧!'.format(result))
                
            elif re.match(r"^U([0-9]{12}) (\w{5,20}) C U (\d+) ([0-9]{12}) (\w{5,20}) (.*) (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)$", data.decode(), flags=re.S):
                result = re.match(r"^U([0-9]{12}) (\w{5,20}) C U (\d+) ([0-9]{12}) (\w{5,20}) (.*) (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)$", data.decode(), flags=re.S).groups()
                self.refresh_friend_text(result[0], result[1], result[2], result[3], result[4], result[5], result[6])
                self.friend_interface_refresh()
                
            elif re.match(r"^G([0-9]{10}) (\w{5,20}) ([0-9]{12}) C U (\d+) ([0-9]{12}) (\w{5,20}) (.*) (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)$", data.decode(), flags=re.S):
                result = re.match(r"^G([0-9]{10}) (\w{5,20}) ([0-9]{12}) C U (\d+) ([0-9]{12}) (\w{5,20}) (.*) (\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)$", data.decode(), flags=re.S).groups()
                self.refresh_group_text(result[0], result[1], result[3], result[4], result[5], result[6], result[7])
                self.group_interface_refresh()
                
            elif re.match(r"^U ([0-9]{12}) not more record$", data.decode()):
                result = re.match(r"^U ([0-9]{12}) not more record$", data.decode()).group(1)
                for friend_text in self.friends:
                    if friend_text[0] == result:
                        friend_text.text.insert(0, (0, '不是id', '没谁了', '没有更多消息', '0000-00-00 00:00:00'))
                        self.friend_interface_refresh()
                        self.text.see('0.0')
                
            elif re.match(r"^G ([0-9]{10}) not more record$", data.decode()):
                result = re.match(r"^G ([0-9]{10}) not more record$", data.decode()).group(1)
                for group_text in self.groups:
                    if group_text[0] == result:
                        group_text.text.insert(0, (0, '不是id', '没谁了', '没有更多消息', '0000-00-00 00:00:00'))
                        self.group_interface_refresh()
                        self.text.see('0.0')
                
            elif re.match(r"^U ([0-9]{12}) m (.*)$", data.decode(), flags=re.S):
                result = re.match(r"^U ([0-9]{12}) m (.*)$", data.decode(), flags=re.S).groups()
                result_list = result[1]
                print(repr(result_list))
                lst = eval(result_list)
                for friend_text in self.friends:
                    if friend_text[0] == result[0]:
                        for tp in lst:
                            print(tp)
                            friend_text.text.append(tp)
                        friend_text.text.sort(key=lambda x: x[0])
                        self.friend_interface_refresh()
                        self.text.see('0.0')
                
            elif re.match(r"^G ([0-9]{10}) m (.*)$", data.decode(), flags=re.S):
                result = re.match(r"^G ([0-9]{10}) m (.*)$", data.decode(), flags=re.S).groups()
                result_list = result[1]
                print(repr(result_list))
                lst = eval(result_list)
                for group_text in self.groups:
                    if group_text[0] == result[0]:
                        for tp in lst:
                            print(tp)
                            group_text.text.append(tp)
                        group_text.text.sort(key=lambda x: x[0])
                        self.group_interface_refresh()
                        self.text.see('0.0')
                
            elif re.match(r"^U([0-9]{12}) R not FR$", data.decode()):
                result = re.match(r"^U([0-9]{12}) R not FR$", data.decode()).group(1)
                self.already_not_friend(result)
                
            elif re.match(r"^G([0-9]{10}) R not MR$", data.decode()):
                result = re.match(r"^G([0-9]{10}) R not MR$", data.decode()).group(1)
                self.already_not_member(result)
                
            elif re.match(r"^successfully created G([0-9]{10}) (\w{5,20})$", data.decode()):
                result = re.match(r"^successfully created G([0-9]{10}) (\w{5,20})$", data.decode()).groups()
                self.groups.append(GroupText(group=(result[0], result[1], self.user_id.get())))
                self.refresh_groups()
                mb.showinfo('创建群成功', '已创建成功, 开始拉人吧!')
                
            elif data.decode() == "group not existed":
                mb.showwarning('群消息', '该群不存在')
                
            elif data.decode() == "u not the member":
                mb.showwarning('群消息', '你已经被踢了, 哈哈哈哈, 老老实实当单身狗吧!')
                
            elif re.match(r"^G ([0-9]{10}) info (.*)$", data.decode()):
                result = re.match(r"^G ([0-9]{10}) info (.*)$", data.decode()).groups()
                print(result)
                self.more_group_info_interface(result[0], eval(result[1]))
                
            elif re.match(r"^G([0-9]{10}) kick U$", data.decode()):
                result = re.match(r"^G([0-9]{10}) kick U$", data.decode()).group(1)
                self.already_not_member(result)
                
            elif re.match(r"^send file addr is (.*) path is (.*) to U ([0-9]{12})$", data.decode()):
                result = re.match(r"^send file addr is (.*) path is (.*) to U ([0-9]{12})$", data.decode()).groups()
                addr = eval(result[0])
                path = result[1]
                friend_id = result[2]
                result = os.path.exists(path)
                if not result:
                    mb.showerror('文件传输', '该路径不存在!')
                    continue
                result = os.path.isfile(path)
                if not result:
                    mb.showerror('文件传输', '这不是个文件!')
                    continue
                file_name = os.path.basename(path)
                file_size = os.path.getsize(path)
                # global q
                # q.put(0)
                q = Queue(1)
                # self.speed_of_progress = tk.StringVar()
                self.already_send_size = 0
                # th = threading.Thread(target=self.send_the_file, args=(friend_id, file_name, file_size, path, addr, q))
                # print('h')
                # th.setDaemon(True)
                # th.start()
                self.send_the_file(friend_id, file_name, file_size, path, addr, q)
                p = Process(target=self.start, args=(friend_id, file_name, file_size, path, addr, q))
                p.daemon = True
                p.start()

            elif re.match(r"^send file addr is (.*) path is (.*) to G ([0-9]{10})$", data.decode()):
                result = re.match(r"^send file addr is (.*) path is (.*) to G ([0-9]{10})$", data.decode()).groups()
                addr = eval(result[0])
                path = result[1]
                group_id = result[2]
                result = os.path.exists(path)
                if not result:
                    mb.showerror('文件传输', '该路径不存在!')
                    continue
                result = os.path.isfile(path)
                if not result:
                    mb.showerror('文件传输', '这不是个文件!')
                    continue
                file_name = os.path.basename(path)
                file_size = os.path.getsize(path)
                # global q
                # q.put(0)
                q = Queue(1)
                # self.speed_of_progress = tk.StringVar()
                self.group_already_send_size = 0
                # th = threading.Thread(target=self.send_the_file, args=(friend_id, file_name, file_size, path, addr, q))
                # print('h')
                # th.setDaemon(True)
                # th.start()
                self.send_the_file_to_group(group_id, file_name, file_size, path, addr, q)
                p = Process(target=self.group_start, args=(group_id, file_name, file_size, path, addr, q))
                p.daemon = True
                p.start()

            elif re.match(r"^U([0-9]{12}) select files (.*)$", data.decode(), re.S):
                result = re.match(r"^U([0-9]{12}) select files (.*)$", data.decode()).groups()
                friend_id = result[0]
                files_tup = eval(result[1])
                self.friend_files_list_interface(friend_id, files_tup)
            elif re.match(r"^G([0-9]{10}) select files (.*)$", data.decode(), re.S):
                result = re.match(r"^G([0-9]{10}) select files (.*)$", data.decode()).groups()
                group_id = result[0]
                files_tup = eval(result[1])
                self.group_files_list_interface(group_id, files_tup)
            elif re.match(r"^down load file (.+) addr is (.+) size is (\d+) from U ([0-9]{12})", data.decode(), re.S):
                result = re.match(r"^down load file (.+) addr is (.+) size is (\d+) from U ([0-9]{12})", data.decode(), re.S).groups()
                file_name = result[0]
                addr = eval(result[1])
                file_size = result[2]
                if eval(file_size) == 0:
                    mb.showerror('文件错误', '文件内容为空')
                    continue
                friend_id = result[3]
                path = 'files/U{}/U{}/'.format(self.user_id.get(), friend_id)
                file_names = re.match(r"(.*?)(?:\.(\w*))?$", file_name).groups()
                if not os.path.exists(path):
                    os.makedirs(path)
                i = 0
                while True:
                    i += 1
                    if os.path.exists(path + file_name):
                        if not file_names[1]:
                            file_name += '({})'.format(i)
                        else:
                            file_name = file_names[0] + '({}).'.format(i) + file_names[1]
                    else:
                        break
                path += file_name
                # global q
                # q.put(0)
                q = Queue(1)
                self.already_down_load_size = 0
                self.down_load_the_file(friend_id, file_name, file_size, path, addr, q)
                p = Process(target=self.down_load, args=(friend_id, file_name, file_size, path, addr, q))
                p.daemon = True
                p.start()

            elif re.match(r"^down load file (.+) addr is (.+) size is (\d+) from G ([0-9]{10})", data.decode(), re.S):
                result = re.match(r"^down load file (.+) addr is (.+) size is (\d+) from G ([0-9]{10})", data.decode(), re.S).groups()
                file_name = result[0]
                addr = eval(result[1])
                file_size = result[2]
                if eval(file_size) == 0:
                    mb.showerror('文件错误', '文件内容为空')
                    continue
                group_id = result[3]
                path = 'files/U{}/G{}/'.format(self.user_id.get(), group_id)
                file_names = re.match(r"(.*?)(?:\.(\w*))?$", file_name).groups()
                if not os.path.exists(path):
                    os.makedirs(path)
                i = 0
                while True:
                    i += 1
                    if os.path.exists(path + file_name):
                        if not file_names[1]:
                            file_name += '({})'.format(i)
                        else:
                            file_name = file_names[0] + '({}).'.format(i) + file_names[1]
                    else:
                        break
                path += file_name
                # global q
                # q.put(0)
                q = Queue(1)
                self.group_already_down_load_size = 0
                self.group_down_load_the_file(group_id, file_name, file_size, path, addr, q)
                p = Process(target=self.group_down_load, args=(group_id, file_name, file_size, path, addr, q))
                p.daemon = True
                p.start()

    def leave(self):
        os._exit(0)


if __name__ == "__main__":
    try:
        root = Root()
        print('hehe')
        # sendfile = sendtoFriendFile(global_friend_id, global_file_name, global_file_size, global_path, global_addr)
    except BaseException as e:
        print('wait:', e)
        time.sleep(1)
        mb.showerror('程序错误', '程序出错了, 请重新登录')
        os._exit(0)
