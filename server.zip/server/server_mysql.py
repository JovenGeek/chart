import pymysql


class ServerMysql(object):
    def __init__(self, user='root', passwd='123456', host='localhost',
                 port=3306, charset='utf8'):
        self.user = user
        self.passwd = passwd
        self.host = host
        self.port = port
        self.charset = charset
        self.create_root_db = """
                             CREATE DATABASE SevenNaughtyWolves DEFAULT CHARACTER SET 'utf8';
                             USE SevenNaughtyWolves;
                             """
        self.create_root_lists = '''
                               CREATE TABLE users_list(
                               userId char(12) primary key,
                               userName varchar(20),
                               userPasswd varchar(16),
                               createTime timestamp
                               );
                               CREATE TABLE users_online_list(
                               userId char(12) primary key,
                               userAddr char(26),
                               onlineTime timestamp
                               );
                               CREATE TABLE groups_list(
                               groupId char(10) primary key,
                               groupName varchar(20),
                               ownerId char(12),
                               ownerName varchar(20),
                               createTime timestamp
                               );'''
        self.open()
        self.init_mysql()

    def open(self):
        self.conn = pymysql.connect(user=self.user, passwd=self.passwd,
                                    host=self.host, port=self.port,
                                    charset=self.charset)
        self.cursor = self.conn.cursor()

    def init_mysql(self):
        try:
            self.cursor.execute("DROP DATABASE IF EXISTS SevenNaughtyWolves;")
            self.cursor.execute("""
                                SELECT SCHEMA_NAME
                                FROM information_schema.SCHEMATA
                                WHERE SCHEMA_NAME
                                REGEXP '(^U[0-9]{12}$)|(^G[0-9]{10}$)';
                                """)
            result = self.cursor.fetchall()
            if result:
                for id in result:
                    self.cursor.execute("DROP DATABASE {};".format(id[0]))
            self.cursor.execute(self.create_root_db)
            self.cursor.execute(self.create_root_lists)
            self.conn.commit()
        except Exception as e:
            print('这里出错:', e)
            self.conn.rollback()

    def register(self, user_id, user_name, user_passwd):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute("USE SevenNaughtyWolves;")
        cursor.execute('''
                            SELECT userId FROM users_list
                            WHERE userId={};
                            '''.format(repr(user_id)))
        result = cursor.fetchone()
        if result:
            cursor.close()
            conn.close()
            return "user existed"

        try:
            cursor.execute("USE SevenNaughtyWolves;")
            cursor.execute('''
                                INSERT INTO users_list(
                                userId, userName, userPasswd
                                ) VALUES(
                                {}, {}, {}
                                );'''.format(repr(user_id), repr(user_name), repr(user_passwd)))
            cursor.execute("CREATE DATABASE U{} DEFAULT CHARACTER SET utf8;".format(user_id))
            cursor.execute("USE U{};".format(user_id))
            cursor.execute("""
                                CREATE TABLE user_info(
                                userId char(12) primary key,
                                userName varchar(20),
                                userPasswd varchar(16),
                                createTime timestamp
                                );
                                CREATE TABLE friends_list(
                                userId char(12) primary key,
                                userName varchar(20),
                                addTime timestamp
                                );
                                CREATE TABLE groups_list(
                                groupId char(10) primary key,
                                groupName varchar(20),
                                ownerId char(12),
                                ownerName varchar(20),
                                joinTime timestamp
                                );
                                CREATE TABLE user_login_record(
                                userId char(12),
                                userAddr char(26),
                                loginTime timestamp
                                );
                                CREATE TABLE add_friend_record(
                                userId char(12),
                                fromorto char(26),
                                recordTime timestamp
                                );
                                """)
            cursor.execute("""
                                INSERT INTO user_info(
                                userId, userName, userPasswd
                                )
                                VALUES({}, {}, {});
                                """.format(repr(user_id), repr(user_name), repr(user_passwd)))
            conn.commit()
            cursor.close()
            conn.close()
            return "successfully registered"
        except Exception as e:
            print(e)
            conn.rollback()

    def login(self, user_id, user_passwd, addr):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute("USE SevenNaughtyWolves;")
        cursor.execute("""
                            SELECT userId, userName, userPasswd FROM users_list
                            WHERE userId={};
                            """.format(repr(user_id)))
        result = cursor.fetchone()
        if not result:
            cursor.close()
            conn.close()
            return 'user not exists'
        elif result[2] != user_passwd:
            cursor.close()
            conn.close()
            return 'passwd error'
        user_name = result[1]
        print(user_name)
        cursor.execute("""
                            SELECT userId, userAddr FROM users_online_list
                            WHERE userId={};
                            """.format(repr(user_id)))
        result = cursor.fetchone()
        if result:
            try:
                cursor.execute('''
                                    DELETE FROM users_online_list
                                    WHERE userId={};
                                    '''.format(repr(user_id)))
                cursor.execute('''
                                    INSERT INTO users_online_list(
                                    userId, userAddr)VALUES({}, {});
                                    '''.format(repr(user_id), repr(repr(addr))))
                cursor.execute("USE U{};".format(user_id))
                cursor.execute("""
                                    INSERT INTO user_login_record(
                                    userId, userAddr
                                    )
                                    VALUES({}, {});
                                    """.format(repr(user_id), repr(repr(addr))))
                conn.commit()
                cursor.execute('''
                               SELECT userId, userName FROM friends_list
                               ''')
                friends_tuple = cursor.fetchall()
                print(friends_tuple)
                respose = 'successfully logined {} '.format(user_name)
                for tp in friends_tuple:
                    respose += 'U{} {} '.format(tp[0], tp[1])
                cursor.execute('''
                               SELECT groupId, groupName, ownerId FROM groups_list
                               ''')
                groups_tuple = cursor.fetchall()
                print(groups_tuple)
                for tp in groups_tuple:
                    respose += 'G{} {} {}'.format(tp[0], tp[1], tp[2])
                cursor.close()
                conn.close()
                # 返回上一个登录地址
                return (result[1], respose)
            except Exception as e:
                print("这里吧:", e)
                conn.rollback()

        try:
            cursor.execute('''
                                INSERT INTO users_online_list(userId, userAddr)
                                VALUES({}, {});
                                '''.format(repr(user_id), repr(repr(addr))))
            cursor.execute("USE U{};".format(user_id))
            cursor.execute("""
                                INSERT INTO user_login_record(userId, userAddr)
                                VALUES({}, {});
                                """.format(repr(user_id), repr(repr(addr))))
            conn.commit()
            cursor.execute('''
                           SELECT userId, userName FROM friends_list
                           ''')
            friends_tuple = cursor.fetchall()
            print(friends_tuple)
            respose = 'successfully logined {} '.format(user_name)
            for tp in friends_tuple:
                respose += 'U{} {} '.format(tp[0], tp[1])
            cursor.execute('''
                           SELECT groupId, groupName, ownerId FROM groups_list
                           ''')
            groups_tuple = cursor.fetchall()
            print(groups_tuple)
            for tp in groups_tuple:
                respose += 'G{} {} {}'.format(tp[0], tp[1], tp[2])
            cursor.close()
            conn.close()
            return respose
        except Exception as e:
            print("那里", e)
            conn.rollback()

    def add_friend(self, from_id, to_id):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute("USE SevenNaughtyWolves;")
        print('a')
        cursor.execute("""
                            SELECT userId, userName, userPasswd FROM users_list
                            WHERE userId={};
                            """.format(repr(to_id)))
        print('b')
        result = cursor.fetchone()
        if not result:
            cursor.close()
            conn.close()
            return 'find user not exists'
        cursor.execute("""
                            SELECT userId, userAddr FROM users_online_list
                            WHERE userId={};
                            """.format(repr(to_id)))
        result = cursor.fetchone()
        try:
            cursor.execute("USE U{};".format(to_id))
            cursor.execute("""
                                INSERT INTO add_friend_record(userId, fromorto)
                                VALUES({}, {});
                                """.format(repr(from_id), repr('from')))
            cursor.execute("USE U{};".format(from_id))
            cursor.execute("""
                            SELECT * FROM friends_list WHERE userId={};
                            """.format(repr(to_id)))
            if cursor.fetchone():
                return 'already friend'
            cursor.execute("""
                                INSERT INTO add_friend_record(userId, fromorto)
                                VALUES({}, {});
                                """.format(repr(to_id), repr('to')))
            conn.commit()
            if result:
                return ('send', result[1])
            return 'keep'
        except Exception as e:
            print("这里1", e)
            conn.rollback()

    def add_group(self, from_id, group_id):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute("USE SevenNaughtyWolves;")
        cursor.execute("""
                            SELECT groupId, groupName, ownerId FROM groups_list
                            WHERE groupId={};
                            """.format(repr(group_id)))
        result = cursor.fetchone()
        if not result:
            cursor.close()
            conn.close()
            return 'find group not exists'
        cursor.execute("""
                            SELECT userId, userAddr FROM users_online_list
                            WHERE userId={};
                            """.format(repr(result[2])))
        result = cursor.fetchone()
        try:
            cursor.execute("USE G{};".format(group_id))
            cursor.execute("""
                            SELECT * FROM members_list WHERE memberId={};
                            """.format(repr(from_id)))
            if cursor.fetchone():
                return 'already member'
            cursor.execute("""
                                INSERT INTO add_member_record(memberId, fromorto)
                                VALUES({}, {});
                                """.format(repr(from_id), repr('from')))

            conn.commit()
            if result:
                return ('send', result[1])
            return 'keep'
        except Exception as e:
            print("这里1", e)
            conn.rollback()

    def user_refuse_add_friend(self, from_id, to_id):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute("USE SevenNaughtyWolves;")
        cursor.execute("""
                            SELECT userId, userAddr FROM users_online_list
                            WHERE userId={};
                            """.format(repr(to_id)))
        result = cursor.fetchone()
        try:
            cursor.execute("USE U{};".format(to_id))
            cursor.execute("""
                                INSERT INTO add_friend_record(userId, fromorto)
                                VALUES({}, {});
                                """.format(repr(from_id), repr('refuseu')))
            cursor.execute("USE U{};".format(from_id))
            cursor.execute("""
                                INSERT INTO add_friend_record(userId, fromorto)
                                VALUES({}, {});
                                """.format(repr(to_id), repr('urefuse')))
            conn.commit()
            if result:
                return ('send', result[1])
            return 'keep'
        except Exception as e:
            print("这里2", e)
            conn.rollback()

    def group_refuse_add(self, group_id, to_id):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute("USE SevenNaughtyWolves;")
        cursor.execute("""
                            SELECT userId, userAddr FROM users_online_list
                            WHERE userId={};
                            """.format(repr(to_id)))
        result = cursor.fetchone()
        if result:
            return ('send', result[1])
        return 'keep'

    def user_agree_add_friend(self, from_id, to_id):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute("USE SevenNaughtyWolves;")
        cursor.execute("""
                            SELECT userId, userAddr FROM users_online_list
                            WHERE userId={};
                            """.format(repr(to_id)))
        result = cursor.fetchone()
        try:
            cursor.execute("USE U{};".format(to_id))
            cursor.execute("""
                                INSERT INTO add_friend_record(userId, fromorto)
                                VALUES({}, {});
                                """.format(repr(from_id), repr('agreeu')))
            cursor.execute("""
                                SELECT * FROM user_info;
                                """)
            to_name = cursor.fetchone()[1]
            to_content = '你好, 我是{}'.format(to_name)
            print(to_name)
            cursor.execute("USE U{};".format(from_id))
            cursor.execute("""
                                INSERT INTO add_friend_record(userId, fromorto)
                                VALUES({}, {});
                                """.format(repr(to_id), repr('uagree')))
            cursor.execute("""
                                SELECT * FROM user_info;
                                """)
            from_name = cursor.fetchone()[1]
            from_content = '你好, 我是{}'.format(from_name)
            print(from_name)
            print('1')
            cursor.execute("""
                            SELECT * FROM friends_list WHERE userId={}
                            """.format(repr(to_id)))
            if cursor.fetchone():
                return 'already friend'
            cursor.execute("""
                                INSERT INTO friends_list(userId, userName)
                                VALUES({}, {});
                                """.format(repr(to_id), repr(to_name)))
            cursor.execute("""
                            CREATE TABLE IF NOT EXISTS U{0}(
                            Id bigint UNSIGNED PRIMARY KEY AUTO_INCREMENT,
                            userId char(12),
                            userName varchar(20),
                            content TEXT,
                            sendTime timestamp
                             );
                            CREATE TABLE IF NOT EXISTS U{0}FilesRecord(
                            Id bigint UNSIGNED PRIMARY KEY AUTO_INCREMENT,
                            fromId char(12),
                            toId char(12),
                            fileName TEXT,
                            fileSize bigint,
                            sendTime timestamp
                             ); 
                            INSERT INTO U{0}(userId, userName, content)
                            VALUES('{0}', {1}, {2});
                """.format(to_id, repr(to_name), repr(to_content)))
            cursor.execute('SELECT * FROM U{} ORDER BY Id DESC LIMIT 1'.format(to_id))
            to_first = cursor.fetchone()
            print(repr(to_first))
            cursor.execute("USE U{};".format(to_id))
            print('2')
            cursor.execute("""
                                INSERT INTO friends_list(userId, userName)
                                VALUES({}, {});
                                """.format(repr(from_id), repr(from_name)))
            print('4')
            cursor.execute("""
                            CREATE TABLE IF NOT EXISTS U{0}(
                            Id bigint UNSIGNED PRIMARY KEY AUTO_INCREMENT,
                            userId char(12),
                            userName varchar(20),
                            content TEXT,
                            sendTime timestamp
                             );
                            CREATE TABLE IF NOT EXISTS U{0}FilesRecord(
                            Id bigint UNSIGNED PRIMARY KEY AUTO_INCREMENT,
                            fromId char(12),
                            toId char(12),
                            fileName TEXT,
                            fileSize bigint,
                            sendTime timestamp
                             ); 
                            INSERT INTO U{0}(userId, userName, content)
                            VALUES('{0}', {1}, {2});
                """.format(from_id, repr(from_name), repr(from_content)))
            cursor.execute('SELECT * FROM U{} ORDER BY Id DESC LIMIT 1'.format(from_id))
            from_first = cursor.fetchone()
            print(repr(from_first[4]), repr(str(from_first[4])))
            print('3')
            conn.commit()
            from_msg = (from_first[0], from_name, from_first[1], from_first[2], from_first[3], str(from_first[4]))
            to_msg = (to_first[0], to_name, to_first[1], to_first[2], to_first[3], str(to_first[4]))
            if result:
                return ('send', result[1], from_msg, to_msg)
            return ('keep', result, from_msg, to_msg)
        except Exception as e:
            print("这里3", e)
            conn.rollback()

    def group_agreed_add(self, group_id, to_id):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute("USE SevenNaughtyWolves;")
        cursor.execute("""
                            SELECT userId, userAddr FROM users_online_list
                            WHERE userId={};
                            """.format(repr(to_id)))
        to_addr = cursor.fetchone()[1]
        cursor.execute('USE U{};'.format(to_id))
        cursor.execute('SELECT * FROM user_info;')
        to_name = cursor.fetchone()[1]
        to_content = '大家好, 我是{}'.format(to_name)
        try:
            cursor.execute('USE G{};'.format(group_id))
            cursor.execute("SELECT groupId, groupName, ownerId, ownerName FROM group_info;")
            group_info = cursor.fetchone()
            cursor.execute("""
                            INSERT INTO add_member_record(memberId, fromorto)
                                VALUES({}, {});
                                """.format(repr(to_id), repr('agree')))
            cursor.execute("""
                            INSERT INTO chat_record(
                            memberId, memberName, content
                            )
                            VALUES({}, {}, {});
                            """.format(repr(to_id), repr(to_name), repr(to_content)))
            cursor.execute("""
                            SELECT memberId, memberName FROM members_list;
                            """)
            members_tup = cursor.fetchall()
            cursor.execute("""
                            INSERT INTO members_list(
                            memberId, memberName
                            ) 
                            VALUES({}, {});
                            """.format(repr(to_id), repr(to_name)))
            cursor.execute('SELECT * FROM chat_record WHERE memberId={} ORDER BY memberId DESC LIMIT 1'.format(repr(to_id)))
            to_first = cursor.fetchone()
            cursor.execute("USE SevenNaughtyWolves;")
            members_list = []
            for member in members_tup:
                cursor.execute("""
                                SELECT userAddr FROM users_online_list
                                WHERE userId={};
                                """.format(repr(member[0])))
                member_addr = cursor.fetchone()[0]
                members_list.append((member[0], member[1], member_addr))
            members_tup = tuple(members_list)
            cursor.execute('USE U{};'.format(to_id))
            print('fiejje')
            cursor.execute("""
                            INSERT INTO groups_list(
                            groupId, groupName, ownerId, ownerName
                            )
                            VALUES({}, {}, {}, {});
                            """.format(repr(group_info[0]), repr(group_info[1]), repr(group_info[2]), repr(group_info[3])))
            conn.commit()
            members_msg = (to_first[0], to_first[1], to_first[2], to_first[3], str(to_first[4]))
            if to_addr:
                return ('send', group_info, members_tup, members_msg, to_addr)
            return ('keep', group_info, members_tup, members_msg, to_addr)
        except Exception as e:
            print("这里3", e)
            conn.rollback()



    def friend_chat(self, from_id, to_id, content):
        try:
            conn = pymysql.connect(user=self.user, passwd=self.passwd,
                                   host=self.host, port=self.port,
                                   charset=self.charset)
            cursor = conn.cursor()
            cursor.execute("USE SevenNaughtyWolves;")
            cursor.execute("""
                                SELECT userId, userAddr FROM users_online_list
                                WHERE userId={};
                                """.format(repr(to_id)))
            result = cursor.fetchone()
            cursor.execute('USE U{};'.format(from_id))
            cursor.execute('''
                            SELECT * FROM friends_list
                            WHERE userId={};
                           '''.format(repr(to_id)))
            isfriend = cursor.fetchone()
            if not isfriend:
                return 'not friend'
            to_name = isfriend[1]
            cursor.execute('''
                            SELECT userName FROM user_info;
                           ''')
            from_name = cursor.fetchone()[0]
            cursor.execute("""
                            INSERT INTO U{0}(userId, userName, content)
                            VALUES('{1}', {2}, {3});
                           """.format(to_id, from_id, repr(from_name), repr(content)))
            # select * from table order by id desc limit 1;
            cursor.execute('''
                            SELECT * FROM U{} ORDER BY Id DESC LIMIT 1;
                           '''.format(to_id))
            from_tup = cursor.fetchone()
            cursor.execute('USE U{};'.format(to_id))
            cursor.execute('''
                            INSERT INTO U{0}(userId, userName, content)
                            VALUES('{1}', {2}, {3});
                           '''.format(from_id, from_id, repr(from_name), repr(content)))
            cursor.execute('''
                            SELECT * FROM U{} ORDER BY Id DESC LIMIT 1;
                           '''.format(from_id))
            to_tup = cursor.fetchone()
            conn.commit()
            cursor.close()
            conn.close()
            from_msg = (from_tup[0], from_name, from_tup[1], from_tup[2], from_tup[3], str(from_tup[4]))
            to_msg = (to_tup[0], to_name, to_tup[1], to_tup[2], to_tup[3], str(to_tup[4]))
            if result:
                return ('send', result[1], from_msg, to_msg)
            return ('keep', result, from_msg, to_msg)
        except Exception as e:
            print('friend_chat:', e)
            conn.rollback()

    def user_send_file_to_friend(self, from_id, to_id, file_name, file_size):
        try:
            conn = pymysql.connect(user=self.user, passwd=self.passwd,
                                   host=self.host, port=self.port,
                                   charset=self.charset)
            cursor = conn.cursor()
            cursor.execute("USE SevenNaughtyWolves;")
            cursor.execute('''
                                SELECT userId FROM users_list
                                WHERE userId={};
                                '''.format(repr(to_id)))
            result = cursor.fetchone()
            if not result:
                cursor.close()
                conn.close()
                return "user not exists"
            cursor.execute('USE U{};'.format(from_id))
            cursor.execute('''
                                SELECT * FROM friends_list
                                WHERE userId={};
                               '''.format(repr(to_id)))
            isfriend = cursor.fetchone()
            if not isfriend:
                cursor.close()
                conn.close()
                return 'not friend'
            cursor.execute("USE U{};".format(from_id))
            cursor.execute("""
                            INSERT INTO U{1}FilesRecord(
                            fromId, toId, fileName, fileSize
                            )
                            VALUES ({0}, '{1}', {2}, {3})
                            """.format(repr(from_id), to_id, repr(file_name), repr(file_size)))
            cursor.execute("SELECT * FROM U{}FilesRecord ORDER BY Id DESC LIMIT 1".format(to_id))
            file_info = cursor.fetchone()
            cursor.execute("USE U{};".format(to_id))
            cursor.execute("""
                            INSERT INTO U{0}FilesRecord(
                            fromId, toId, fileName, fileSize
                            )
                            VALUES ('{0}', {1}, {2}, {3})
                            """.format(from_id, repr(to_id), repr(file_name), repr(file_size)))
            conn.commit()
            cursor.close()
            conn.close()
            return file_info
        except Exception as e:
            print('friend_chat:', e)
            conn.rollback()

    def group_send_file(self, from_id, group_id, file_name, file_size):
        try:
            conn = pymysql.connect(user=self.user, passwd=self.passwd,
                                   host=self.host, port=self.port,
                                   charset=self.charset)
            cursor = conn.cursor()
            cursor.execute("USE SevenNaughtyWolves;")
            cursor.execute('''
                                SELECT groupId FROM groups_list
                                WHERE groupId={};
                                '''.format(repr(group_id)))
            result = cursor.fetchone()
            if not result:
                cursor.close()
                conn.close()
                return "group not existed"
            cursor.execute('USE U{};'.format(from_id))
            cursor.execute('''
                                SELECT * FROM groups_list
                                WHERE groupId={};
                               '''.format(repr(group_id)))
            isMember = cursor.fetchone()
            if not isMember:
                cursor.close()
                conn.close()
                return 'not member'
            cursor.execute("USE G{};".format(group_id))
            cursor.execute("""
                            INSERT INTO files_list(
                            fromId, toId, fileName, fileSize
                            )
                            VALUES ({0}, {1}, {2}, {3})
                            """.format(repr(from_id), repr(group_id), repr(file_name), repr(file_size)))
            cursor.execute("SELECT * FROM files_list ORDER BY Id DESC LIMIT 1;")
            file_info = cursor.fetchone()
            conn.commit()
            cursor.close()
            conn.close()
            return file_info
        except Exception as e:
            print('friend_chat:', e)
            conn.rollback()

    def user_select_files_from_friend(self, from_id, friend_id):
        try:
            conn = pymysql.connect(user=self.user, passwd=self.passwd,
                                   host=self.host, port=self.port,
                                   charset=self.charset)
            cursor = conn.cursor()
            cursor.execute("USE SevenNaughtyWolves;")
            cursor.execute('''
                                SELECT userId FROM users_list
                                WHERE userId={};
                                '''.format(repr(friend_id)))
            result = cursor.fetchone()
            print('result', result)
            if not result:
                cursor.close()
                conn.close()
                return "user not exists"
            cursor.execute('USE U{};'.format(from_id))
            cursor.execute('''
                                SELECT * FROM friends_list
                                WHERE userId={};
                               '''.format(repr(friend_id)))
            isfriend = cursor.fetchone()
            print("isfriend", isfriend)
            if not isfriend:
                cursor.close()
                conn.close()
                return 'not friend'
            cursor.execute("""
                            SELECT * FROM U{}FilesRecord;
                            """.format(friend_id))
            files_info = cursor.fetchall()
            print(files_info)
            files_list = []
            for file_info in files_info:
                file_tup = (file_info[0], file_info[1], file_info[2], file_info[3], file_info[4], str(file_info[5]))
                files_list.append(file_tup)
            files_tup = tuple(files_list)
            conn.commit()
            cursor.close()
            conn.close()
            return files_tup
        except Exception as e:
            print('这里出错了', e)
            conn.rollback()

    def user_select_files_from_group(self, from_id, group_id):
        try:
            conn = pymysql.connect(user=self.user, passwd=self.passwd,
                                   host=self.host, port=self.port,
                                   charset=self.charset)
            cursor = conn.cursor()
            cursor.execute("USE SevenNaughtyWolves;")
            cursor.execute('''
                                SELECT groupId FROM groups_list
                                WHERE groupId={};
                                '''.format(repr(group_id)))
            result = cursor.fetchone()
            if not result:
                cursor.close()
                conn.close()
                return "group not existed"
            cursor.execute('USE U{};'.format(from_id))
            cursor.execute('''
                                SELECT * FROM groups_list
                                WHERE groupId={};
                               '''.format(repr(group_id)))
            isMember = cursor.fetchone()
            if not isMember:
                cursor.close()
                conn.close()
                return 'not member'
            cursor.execute("USE G{};".format(group_id))
            cursor.execute("SELECT * FROM files_list;")
            files_info = cursor.fetchall()
            print(files_info)
            files_list = []
            for file_info in files_info:
                file_tup = (file_info[0], file_info[1], file_info[2], file_info[3], file_info[4], str(file_info[5]))
                files_list.append(file_tup)
            files_tup = tuple(files_list)
            conn.commit()
            cursor.close()
            conn.close()
            return files_tup
        except Exception as e:
            print('这里出错了', e)
            conn.rollback()

    def group_chat(self, from_id, group_id, from_content):
        try:
            conn = pymysql.connect(user=self.user, passwd=self.passwd,
                                   host=self.host, port=self.port,
                                   charset=self.charset)
            cursor = conn.cursor()
            cursor.execute("USE SevenNaughtyWolves;")
            cursor.execute("""
                                SELECT groupId FROM groups_list
                                WHERE groupId={};
                                """.format(repr(group_id)))
            if not cursor.fetchone():
                cursor.close()
                conn.close()
                return "group not existed"
            cursor.execute('USE U{};'.format(from_id))
            cursor.execute('SELECT * FROM user_info;')
            from_name = cursor.fetchone()[1]
            cursor.execute('USE G{};'.format(group_id))
            cursor.execute('SELECT * FROM members_list WHERE memberId={};'.format(repr(from_id)))
            if not cursor.fetchone():
                cursor.close()
                conn.close()
                return 'not member'
            cursor.execute("SELECT groupId, groupName, ownerId, ownerName FROM group_info;")
            group_info = cursor.fetchone()
            cursor.execute("""
                            INSERT INTO chat_record(
                            memberId, memberName, content
                            )
                            VALUES({}, {}, {});
                            """.format(repr(from_id), repr(from_name), repr(from_content)))
            cursor.execute('SELECT * FROM chat_record ORDER BY Id DESC LIMIT 1')
            from_content = cursor.fetchone()
            cursor.execute("""
                            SELECT memberId, memberName FROM members_list;
                            """)
            members_tup = cursor.fetchall()
            cursor.execute("USE SevenNaughtyWolves;")
            members_list = []
            for member in members_tup:
                cursor.execute("""
                                SELECT userAddr FROM users_online_list
                                WHERE userId={};
                                """.format(repr(member[0])))
                member_addr = cursor.fetchone()[0]
                members_list.append((member[0], member[1], member_addr))
            members_tup = tuple(members_list)
            members_msg = (from_content[0], from_content[1], from_content[2], from_content[3], str(from_content[4]))
            conn.commit()
            cursor.close()
            conn.close()
            return ('keep', group_info, members_tup, members_msg)
        except Exception as e:
            print('eifjie', e)
            conn.rollback()



    def more_friend_record(self, from_id, to_id, earliest_id):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute('USE U{};'.format(from_id))
        try:
            if not earliest_id:
                print('earliest_id:', earliest_id)
                # select * from table order by id desc limit 1;
                cursor.execute('''
                            SELECT * FROM U{} ORDER BY Id DESC LIMIT 10;
                           '''.format(to_id))
            else:
                cursor.execute('''
                            SELECT * FROM U{} WHERE Id < {}
                            ORDER BY Id DESC LIMIT 10;
                           '''.format(to_id, earliest_id))
            rs = cursor.fetchall()
            if rs:
                print(rs)
                result = list(map(lambda x: (x[0], x[1], x[2], x[3], str(x[-1])), rs))
                print(result)
            else:
                result = rs
            return result
        except Exception as e:
            print('hehe', e)

    def more_group_record(self, from_id, group_id, earliest_id):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute('USE G{};'.format(group_id))
        try:
            if not earliest_id:
                print('earliest_id:', earliest_id)
                # select * from table order by id desc limit 1;
                cursor.execute('''
                            SELECT * FROM chat_record ORDER BY Id DESC LIMIT 10;
                           ''')
            else:
                cursor.execute('''
                            SELECT * FROM chat_record WHERE Id < {}
                            ORDER BY Id DESC LIMIT 10;
                           '''.format(repr(earliest_id)))
            rs = cursor.fetchall()
            if rs:
                print(rs)
                result = list(map(lambda x: (x[0], x[1], x[2], x[3], str(x[-1])), rs))
                print(result)
            else:
                result = rs
            return result
        except Exception as e:
            print('hehe', e)

    def user_delete_friend(self, from_id, to_id):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute('USE U{};'.format(from_id))
        cursor.execute('''
                            SELECT * FROM friends_list WHERE userId={};
                           '''.format(repr(to_id)))
        result = cursor.fetchone()
        if result:
            try:
                cursor.execute('''
                                DELETE FROM friends_list WHERE userId={};
                               '''.format(repr(to_id)))
                cursor.execute('USE U{};'.format(to_id))
                cursor.execute('''
                            SELECT * FROM friends_list WHERE userId={};
                           '''.format(repr(from_id)))
                result = cursor.fetchone()
                if result:
                    cursor.execute('''
                                    DELETE FROM friends_list WHERE userId={};
                                   '''.format(repr(from_id)))
                conn.commit()
                cursor.close()
                conn.close()
                return
            except Exception as e:
                conn.rollback()
                print('heheke:', e)
        cursor.close()
        conn.close()
        return 'not f'

    def group_delete(self, from_id, group_id):
        try:
            conn = pymysql.connect(user=self.user, passwd=self.passwd,
                                   host=self.host, port=self.port,
                                   charset=self.charset)
            cursor = conn.cursor()
            cursor.execute("USE SevenNaughtyWolves;")
            cursor.execute('''
                                SELECT groupId FROM groups_list
                                WHERE groupId={};
                                '''.format(repr(group_id)))
            if not cursor.fetchone():
                cursor.close()
                conn.close()
                return 'not m'
            cursor.execute("USE G{};".format(group_id))
            cursor.execute("SELECT ownerId from group_info;")
            owner_id = cursor.fetchone()[0]
            cursor.execute("""
                            SELECT * FROM members_list WHERE memberId={};
                            """.format(repr(from_id)))
            if not cursor.fetchone():
                cursor.close()
                conn.close()
                return 'not m'
            print(owner_id, from_id)
            if owner_id == from_id:
                cursor.execute("""
                                SELECT memberId, memberName FROM members_list;
                                """)
                members_tup = cursor.fetchall()
                cursor.execute("USE SevenNaughtyWolves;")
                cursor.execute("""
                                DELETE FROM groups_list WHERE groupId={}
                                """.format(repr(group_id)))
                members_list = []
                for member in members_tup:
                    cursor.execute("USE SevenNaughtyWolves;")
                    cursor.execute("""
                                    SELECT userAddr FROM users_online_list
                                    WHERE userId={};
                                    """.format(repr(member[0])))
                    member_addr = cursor.fetchone()[0]
                    cursor.execute("USE U{}".format(member[0]))
                    cursor.execute("""
                                    DELETE FROM groups_list WHERE groupId={}
                                    """.format(repr(group_id)))
                    if member[0] != from_id:
                        members_list.append((member[0], member[1], member_addr))
                members_tup = tuple(members_list)
                cursor.execute("DROP DATABASE G{};".format(group_id))
                conn.commit()
                cursor.close()
                conn.close()
                return members_tup

            cursor.execute("""
                            DELETE FROM members_list WHERE memberId={};
                            """.format(repr(from_id)))
            cursor.execute('USE U{};'.format(from_id))
            cursor.execute("""
                            SELECT * FROM groups_list WHERE groupId={};
                            """.format(repr(group_id)))
            result = cursor.fetchone()
            if not result:
                cursor.close()
                conn.close()
                return 'not m'
            cursor.execute("""
                            DELETE FROM groups_list WHERE groupId={};
                            """.format(repr(group_id)))
            conn.commit()
            cursor.close()
            conn.close()
        except Exception as e:
            print('回滚了', e)
            conn.rollback()

    def group_create(self, group_id, group_name, owner_id, owner_name):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute("USE SevenNaughtyWolves;")
        cursor.execute('''
                            SELECT groupId FROM groups_list
                            WHERE groupId={};
                            '''.format(repr(group_id)))
        result = cursor.fetchone()
        if result:
            cursor.close()
            conn.close()
            return "group existed"

        try:
            cursor.execute("USE SevenNaughtyWolves;")
            cursor.execute('''
                                INSERT INTO groups_list(
                                groupId, groupName, ownerId, ownerName
                                ) VALUES(
                                {}, {}, {}, {}
                                );'''.format(repr(group_id), repr(group_name), repr(owner_id), repr(owner_name)))
            cursor.execute("CREATE DATABASE G{} DEFAULT CHARACTER SET utf8;".format(group_id))
            cursor.execute("USE G{};".format(group_id))
            cursor.execute("""
                                CREATE TABLE group_info(
                                groupId char(10) primary key,
                                groupName varchar(20),
                                ownerId char(12),
                                ownerName varchar(20),
                                createTime timestamp
                                );
                                CREATE TABLE members_list(
                                memberId char(12) primary key,
                                memberName varchar(20),
                                addTime timestamp
                                );
                                CREATE TABLE files_list(
                                Id bigint UNSIGNED PRIMARY KEY AUTO_INCREMENT,
                                fromId char(12),
                                toId char(12),
                                fileName TEXT,
                                fileSize bigint,
                                sendTime timestamp
                                );
                            --     CREATE TABLE IF NOT EXISTS U{0}FilesRecord(
                            -- Id bigint UNSIGNED PRIMARY KEY AUTO_INCREMENT,
                            -- fromId char(12),
                            -- toId varchar(20),
                            -- fileName TEXT,
                            -- fileSize bigint,
                            -- sendTime timestamp
                            --  );
                                CREATE TABLE add_member_record(
                                memberId char(12),
                                fromorto char(26),
                                recordTime timestamp
                                );
                                CREATE TABLE chat_record(
                                Id bigint UNSIGNED PRIMARY KEY AUTO_INCREMENT,
                                memberId char(12),
                                memberName varchar(20),
                                content TEXT,
                                sendTime timestamp
                                );
                                """)
            cursor.execute("""
                                INSERT INTO group_info(
                                groupId, groupName, ownerId, ownerName
                                )
                                VALUES({}, {}, {}, {});
                                """.format(repr(group_id), repr(group_name), repr(owner_id), repr(owner_name)))
            cursor.execute("""
                            INSERT INTO members_list(
                                memberId, memberName
                                )
                                VALUES({}, {});
                            """.format(repr(owner_id), repr(owner_name)))
            cursor.execute("""
                            INSERT INTO add_member_record(
                            memberId, fromorto
                            )
                            VALUES({}, {});
                            """.format(repr(owner_id), repr('as owner')))
            first_record = '{}已经创建了该群'.format(owner_name)
            cursor.execute("""
                            INSERT INTO chat_record(
                            memberId, memberName, content
                            )
                            VALUES({}, {}, {});
                            """.format(repr(owner_id), repr(owner_name), repr(first_record)))
            print('jfie')
            cursor.execute('USE U{};'.format(owner_id))
            print('fiejje')
            cursor.execute("""
                            INSERT INTO groups_list(
                            groupId, groupName, ownerId, ownerName
                            )
                            VALUES({}, {}, {}, {});
                            """.format(repr(group_id), repr(group_name), repr(owner_id), repr(owner_name)))
            print('fijeijf')
            conn.commit()
            cursor.close()
            conn.close()
            return "successfully created G{} {}".format(group_id, group_name)
        except Exception as e:
            print(e)
            conn.rollback()

    def group_more_info(self, from_id, group_id):
        conn = pymysql.connect(user=self.user, passwd=self.passwd,
                               host=self.host, port=self.port,
                               charset=self.charset)
        cursor = conn.cursor()
        cursor.execute("USE SevenNaughtyWolves;")
        cursor.execute('''
                            SELECT groupId FROM groups_list
                            WHERE groupId={};
                            '''.format(repr(group_id)))
        result = cursor.fetchone()
        if not result:
            cursor.close()
            conn.close()
            return "group not existed"
        cursor.execute("USE G{};".format(group_id))
        cursor.execute("""
                        SELECT * FROM members_list
                        WHERE memberId={};
                        """.format(repr(from_id)))
        result = cursor.fetchone()
        if not result:
            cursor.close()
            conn.close()
            return 'u not the member'
        cursor.execute("""
                        SELECT ownerId, ownerName FROM group_info;
                        """)
        owner_msg = cursor.fetchone()
        cursor.execute("""
                        SELECT memberId, memberName FROM members_list;
                        """)
        members_msg = cursor.fetchall()
        return (owner_msg, members_msg)

    def close(self):
        self.cursor.close()
        self.conn.close()
