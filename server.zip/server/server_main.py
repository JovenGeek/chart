from socket import *
import sys
import server_mysql
import re
import random
from socketserver import ThreadingUDPServer, DatagramRequestHandler
import time
import os
import shutil
import signal

# 功能字符 U 为用户 G 为组
# F 传文件 T 翻译 M 监控 A 为添加好友 m更多记录
# R 注册 L 登录 D 注销 C聊天 O登出
# 用户注册
user_register_pattern = r"^U ([0-9]{12}) (\w{5,20}) ([0-9A-Za-z]{6,16}) R"
# 用户登录
user_login_pattern = r"^U ([0-9]{12}) ([0-9A-Za-z]{6,16}) L"
user_login_out_pattern = r"^U ([0-9]{12}) O"
# 用户之间信息交互  F 传文件 T 翻译 M 监控 A 为添加好友 C聊天
user_message_pattern = r"^U ([0-9]{12}) to U ([0-9]{12}) ([mFTMCA]) (.*)"
# 用户发送文件
user_send_file_pattern = r"^U ([0-9]{12}) to U ([0-9]{12}) send (.*) size (.*) path (.*)$"
# 用户拒绝添加好友
user_refuse_add_friend_pattern = r"^U ([0-9]{12}) R U ([0-9]{12})"
# 用户同意添加好友
user_agree_add_friend_pattern = r"^U ([0-9]{12}) A U ([0-9]{12})"
# 用户获取好友文件列表
user_select_files_from_friend_pattern = r"^U ([0-9]{12}) to U ([0-9]{12}) select files"
# 用户下载好友文件
user_down_load_files_from_friend_pattern = r"^U ([0-9]{12}) to U ([0-9]{12}) down file (.+) id (\d+) from ([0-9]{12})"
# 用户删除好友
user_delete_friend_pattern = r'U ([0-9]{12}) D U ([0-9]{12})'
# 用户下载好友文件
user_down_load_files_from_group_pattern = r"^U ([0-9]{12}) to G ([0-9]{10}) down file (.+) id (\d+) from ([0-9]{12})"
# 用户注销
user_unsubscribe_pattern = r"^U ([0-9]{12}) D$"
# 建群
group_create_pattern = r"^G ([0-9]{10}) (\w{5,20}) U ([0-9]{12}) (\w{5,20}) create"
# 群内成员的信息交互 
group_message_pattern = r"^U ([0-9]{12}) to G ([0-9]{10}) ([mFTMCA]) (.*)"
# 拒绝加入群聊
group_refuse_add_pattern = r"G ([0-9]{10}) R U ([0-9]{12})"
# 同意加入群聊
group_agreed_add_pattern = r"G ([0-9]{10}) A U ([0-9]{12})"
# 用户发送群文件
group_send_file_pattern = r"^U ([0-9]{12}) to G ([0-9]{10}) send (.*) size (.*) path (.*)$"
# 用户获取群文件列表
user_select_files_from_group_pattern = r"^U ([0-9]{12}) to G ([0-9]{10}) select files"
# 群聊成员信息
group_more_info_pattern = r"^U ([0-9]{12}) to G ([0-9]{10}) info"
# 退出群聊
group_delete_pattern = r"^U ([0-9]{12}) D G ([0-9]{10})$"
# 群解散
group_unsubscribe_pattern = r"G ([0-9]{10}) D"
# 相应的正则表达式对象
u_r = re.compile(user_register_pattern)
u_l = re.compile(user_login_pattern)
u_o = re.compile(user_login_out_pattern)
u_m = re.compile(user_message_pattern, re.S)
u_s_f = re.compile(user_send_file_pattern, re.S)
u_r_f = re.compile(user_refuse_add_friend_pattern)
u_s_f_f = re.compile(user_select_files_from_friend_pattern)
u_s_f_g = re.compile(user_select_files_from_group_pattern)
u_a_f = re.compile(user_agree_add_friend_pattern)
u_d_l_f_f = re.compile(user_down_load_files_from_friend_pattern, re.S)
u_d_l_f_g = re.compile(user_down_load_files_from_group_pattern, re.S)
u_d_f = re.compile(user_delete_friend_pattern)
u_u = re.compile(user_unsubscribe_pattern)
g_c = re.compile(group_create_pattern)
g_r = re.compile(group_refuse_add_pattern)
g_a = re.compile(group_agreed_add_pattern)
g_s_f = re.compile(group_send_file_pattern, re.S)
g_m = re.compile(group_message_pattern, re.S)
g_d = re.compile(group_delete_pattern)
g_m_i = re.compile(group_more_info_pattern)
g_u = re.compile(group_unsubscribe_pattern)
# 已注册用户列表
userlist = []
# 在线用户列表
user_online = []
# 群列表
grouplist = []

bind_addr = sys.argv[0]

# # 用户类
# class User(object):

#     def __init__(self, user_id, name, password):
#         self.id = user_id
#         self.name = name
#         self.password = password

#     def __getitem__(self, index):
#         return [self.id, self.name, self.password][index]

#     def OnLine(self):
#         self.on_line = Server(('0.0.0.0', self.userport), user_handler).serve_forever()


# 服务器类
class Server(ThreadingUDPServer):
    pass


# 主线程处理类
class Handler(DatagramRequestHandler):

    mysql = server_mysql.ServerMysql()
    if os.path.exists('files/'):
        shutil.rmtree('files/')

    def handle(self):
        print(self.client_address)
        # print(self.request[1].getpeername())
        # 获取客户端命令
        data_list = self.rfile.readlines()
        msg_list = map(lambda x: x.decode(), data_list)
        self.msg = ''.join(msg_list)
        print(self.client_address)
        print(self.msg)
        # 对命令进行解析
        for regex in [u_r, u_l, u_o, u_r_f, u_a_f, u_s_f_g, u_d_l_f_g,  u_s_f_f, g_s_f, u_d_l_f_f, g_r, g_a, g_d, u_s_f, u_d_f, g_m_i, u_m, u_u, g_c, g_m, g_u]:
            result = regex.match(self.msg)
            print(result)
            if not result:
                continue
            self.tup = result.groups()
            if regex == u_r:
                # 注册用户
                self.user_register(self.tup)
                break
            elif regex == u_l:
                # 用户登录
                self.user_login(self.tup, self.client_address)
                break
            elif regex == u_m:
                # 处理信息
                self.user_message(self.tup)
                break
            elif regex == u_s_f:
                self.user_send_file_to_friend(self.tup)
            elif regex == u_r_f:
                self.user_refuse_add_friend(self.tup)
                break
            elif regex == u_a_f:
                self.user_agree_add_friend(self.tup)
                break
            elif regex == u_d_f:
                self.user_delete_friend(self.tup)
                break
            elif regex == u_s_f_f:
                self.user_select_files_from_friend(self.tup)
                break
            elif regex == u_d_l_f_g:
                self.user_down_load_files_from_group(*self.tup)
            elif regex == u_s_f_g:
                self.user_select_files_from_group(self.tup)
            elif regex == u_d_l_f_f:
                self.user_down_load_files_from_friend(*self.tup)
            elif regex == u_u:
                pass
            elif regex == g_c:
                self.group_create(self.tup)
                break
            elif regex == g_m:
                self.group_message(self.tup)
                break
            elif regex == g_m_i:
                self.group_more_info(self.tup)
                break
            elif regex == g_r:
                self.group_refuse_add(self.tup)
                break
            elif regex == g_a:
                self.group_agreed_add(self.tup)
                break
            elif regex == g_d:
                print('g_d')
                self.group_delete(self.tup)
                break
            elif regex == g_s_f:
                self.group_send_file(self.tup)
            elif regex == g_u:
                pass

    def user_send_file_to_friend(self, tup):
        result = Handler.mysql.user_send_file_to_friend(tup[0], tup[1], tup[2], tup[3])
        if result == "user not exists":
            self.wfile.write("user not exists".encode())
        elif result == 'not friend':
            self.wfile.write('U{} not FR'.format(tup[1]).encode())
        elif type(result) == type(tuple()):
            port = self.create_port()
            self.wfile.write('send file addr is {} path is {} to U {}'.format((sys.argv[1], port), tup[4], tup[1]).encode())
            path = 'files/U{}/U{}/{}/'.format(tup[0], tup[1], result[0])
            is_exists = os.path.exists(path)
            if not is_exists:
                os.makedirs(path)
                self.recv_file_from_friend(port, path, tup[2])

    def group_send_file(self, tup):
        result = Handler.mysql.group_send_file(tup[0], tup[1], tup[2], tup[3])
        if result == "group not existed":
            self.wfile.write("group not existed".encode())
        elif result == 'not member':
            self.wfile.write('G{} R not MR'.format(tup[1]).encode())
        elif type(result) == type(tuple()):
            port = self.create_port()
            self.wfile.write('send file addr is {} path is {} to G {}'.format((sys.argv[1], port), tup[4], tup[1]).encode())
            path = 'files/G{}/U{}/{}/'.format(tup[1], tup[0], result[0])
            is_exists = os.path.exists(path)
            if not is_exists:
                os.makedirs(path)
                self.recv_file_from_member(port, path, tup[2])

    def user_select_files_from_friend(self, tup):
        result = Handler.mysql.user_select_files_from_friend(tup[0], tup[1])
        if result == "user not exists":
            self.wfile.write("user not exists".encode())
        elif result == 'not friend':
            self.wfile.write('U{} not FR'.format(tup[1]).encode())
        elif type(result) == type(tuple()):
            self.wfile.write('U{} select files {}'.format(tup[1], result).encode())

    def user_select_files_from_group(self, tup):
        result = Handler.mysql.user_select_files_from_group(tup[0], tup[1])
        if result == "group not existed":
            self.wfile.write("group not existed".encode())
        elif result == 'not member':
            self.wfile.write('G{} R not MR'.format(tup[1]).encode())
        elif type(result) == type(tuple()):
            self.wfile.write('G{} select files {}'.format(tup[1], result).encode())

    def recv_file_from_friend(self, port, path, file_name):

        pid = os.fork()
        if pid == 0:
            s = socket(AF_INET, SOCK_STREAM)
            print((sys.argv[1], port))
            s.bind((sys.argv[1], port))
            s.listen(5)
            print('这边好了')
            sock, addr = s.accept()
            print(sock, addr)
            sock.send(b'OK')
            print('接收到了')
            with open(path + file_name, 'wb') as f:
                while True:
                    print('正在等待')
                    data = sock.recv(1024)
                    print(data)
                    if not data:
                        break
                    length = f.write(data)
                    print(length)
                    print('还没退出')
            time.sleep(1)
            print('退出了')
            os._exit(0)

    def recv_file_from_member(self, port, path, file_name):
        pid = os.fork()
        if pid == 0:
            s = socket(AF_INET, SOCK_STREAM)
            print((sys.argv[1], port))
            s.bind((sys.argv[1], port))
            s.listen(5)
            print('这边好了')
            sock, addr = s.accept()
            print(sock, addr)
            sock.send(b'OK')
            print('接收到了')
            with open(path + file_name, 'wb') as f:
                while True:
                    print('正在等待')
                    data = sock.recv(1024)
                    if not data:
                        break
                    length = f.write(data)
                    print(length)
                    print('还没退出')
            time.sleep(1)
            print('退出了')
            os._exit(0)

    def user_down_load_files_from_friend(self, user_id, friend_id, file_name, file_id, from_id):
        port = self.create_port()
        if user_id == from_id:
            path = 'files/U{}/U{}/{}/'.format(user_id, friend_id, file_id)
        else:
            path = 'files/U{}/U{}/{}/'.format(friend_id, user_id, file_id)
        file_size = os.path.getsize(path + file_name)
        self.wfile.write('down load file {} addr is {} size is {} from U {}'.format(file_name, (sys.argv[1], port), file_size, friend_id).encode())
        self.send_file_to_user(port, path, file_name)

    def user_down_load_files_from_group(self, user_id, group_id, file_name, file_id, from_id):
        port = self.create_port()
        path = 'files/G{}/U{}/{}/'.format(group_id, from_id, file_id)
        file_size = os.path.getsize(path + file_name)
        self.wfile.write('down load file {} addr is {} size is {} from G {}'.format(file_name, (sys.argv[1], port), file_size, group_id).encode())
        self.group_send_file_to_user(port, path, file_name)

    def send_file_to_user(self, port, path, file_name):
        pid = os.fork()
        if pid == 0:
            s = socket(AF_INET, SOCK_STREAM)
            print((sys.argv[1], port))
            s.bind((sys.argv[1], port))
            s.listen(5)
            print('这边好了')
            sock, addr = s.accept()
            print(sock, addr)
            with open(path + file_name, 'rb') as f:
                while True:
                    data = f.read(1024)
                    sock.send(data)
                    print(len(data))
                    print('还没退出')
                    if not data:
                        print('退出了')
                        os._exit(0)

    def group_send_file_to_user(self, port, path, file_name):
        pid = os.fork()
        if pid == 0:
            s = socket(AF_INET, SOCK_STREAM)
            print((sys.argv[1], port))
            s.bind((sys.argv[1], port))
            s.listen(5)
            print('这边好了')
            sock, addr = s.accept()
            print(sock, addr)
            with open(path + file_name, 'rb') as f:
                while True:
                    data = f.read(1024)
                    sock.send(data)
                    print(len(data))
                    print('还没退出')
                    if not data:
                        print('退出了')
                        os._exit(0)

    def create_port(self):
        while True:
            # 随机生成端口
            userport = random.randrange(256, 65535)
            # 判断端口是否可用
            if self.is_open(userport):
                break
        return userport

    # 判断端口是否可用
    def is_open(self, port):
        s = socket(AF_INET, SOCK_DGRAM)
        try:
            s.connect(('0.0.0.0', port))
            s.shutdown(2)
            return True
        except BaseException:
            return False

    def group_more_info(self, group_tup):
        print('hehr')
        result = Handler.mysql.group_more_info(*group_tup)
        print(result)
        if result == "group not existed":
            self.wfile.write("group not existed".encode())
        elif result == 'u not the member':
            self.wfile.write("u not the member".encode())
        elif type(result) == type(tuple()):
            print(result)
            self.wfile.write("G {} info {}".format(group_tup[1], result).encode())

    def group_create(self, group_tup):
        result = Handler.mysql.group_create(*group_tup)
        if result == 'group existed':
            self.wfile.write("group existed".encode())
            return
        self.wfile.write(result.encode())
    # 注册用户方法
    def user_register(self, user_tup):
        result = Handler.mysql.register(*user_tup)
        print(result)
        if result == "user existed":
            self.wfile.write("user existed".encode())
            return
        self.wfile.write(result.encode())

    # 用户登录方法
    def user_login(self, user_tup, addr):
        result = Handler.mysql.login(*user_tup, addr)
        print(result)
        if result == 'user not exists':
            self.wfile.write(result.encode())
            return
        elif result == 'passwd error':
            self.wfile.write(result.encode())
            return
        elif type(result) == type(tuple()):
            self.socket.sendto('remote login'.encode(), eval(result[0]))
            print(self.client_address)
            self.wfile.write(result[1].encode())
            return

        self.wfile.write(result.encode())

    def create_port(self):
        while True:
            # 随机生成端口
            userport = random.randrange(256, 65535)
            # 判断端口是否可用
            if self.is_open(userport):
                break
        return userport

    # 判断端口是否可用
    def is_open(self, port):
        s = socket(AF_INET, SOCK_DGRAM)
        try:
            s.connect(('0.0.0.0', port))
            s.shutdown(2)
            return True
        except BaseException:
            return False

    def user_message(self, tup):
        if tup[2] == 'A':
            self.add_friend(tup)
        elif tup[2] == 'F':
            pass
        elif tup[2] == 'T':
            pass
        elif tup[2] == 'M':
            pass
        elif tup[2] == 'C':
            self.friend_chat(tup)

        elif tup[2] == 'm':
            self.more_friend_record(tup)

    def group_message(self, tup):
        if tup[2] == 'A':
            self.add_group(tup)
        elif tup[2] == 'F':
            pass
        elif tup[2] == 'T':
            pass
        elif tup[2] == 'M':
            pass
        elif tup[2] == 'C':
            self.group_chat(tup)
            pass

        elif tup[2] == 'm':
            self.more_group_record(tup)

    def more_friend_record(self, tup):
        result = Handler.mysql.more_friend_record(tup[0], tup[1], tup[3])
        if not result:
            self.wfile.write('U {} not more record'.format(tup[1]).encode())
        else:
            self.wfile.write('U {} m {}'.format(tup[1], repr(result)).encode())

    def more_group_record(self, tup):
        result = Handler.mysql.more_group_record(tup[0], tup[1], tup[3])
        if not result:
            self.wfile.write('G {} not more record'.format(tup[1]).encode())
        else:
            self.wfile.write('G {} m {}'.format(tup[1], repr(result)).encode())

    def friend_chat(self, tup):
        result = Handler.mysql.friend_chat(tup[0], tup[1], tup[3])
        if result == 'not friend':
            self.wfile.write('U{} not FR'.format(tup[1]).encode())
        elif type(result) == type(tuple()):
            if result[0] == 'send' and tup[0] != tup[1]:
                self.socket.sendto('U{} {} C U {} {} {} {} {}'.format(tup[0], result[2][1], result[2][0], result[2][2], result[2][3], result[2][4], result[2][5]).encode(), eval(result[1]))
            self.wfile.write('U{} {} C U {} {} {} {} {}'.format(tup[1], result[3][1], result[3][0], result[3][2], result[3][3], result[3][4], result[3][5]).encode())

    def group_chat(self, tup):
        result = Handler.mysql.group_chat(tup[0], tup[1], tup[3])
        if result == 'not member':
            self.wfile.write('G{} R not MR'.format(tup[1]).encode())
        elif result == "group not existed":
            self.wfile.write(result.encode())
        elif type(result) == type(tuple()):
            for member in result[2]:
                self.socket.sendto('G{} {} {} C U {} {} {} {} {}'.format(result[1][0], result[1][1], result[1][2], result[3][0], result[3][1], result[3][2], result[3][3], result[3][4]).encode(), eval(member[2]))

    def add_friend(self, tup):
        result = Handler.mysql.add_friend(tup[0], tup[1])
        print(result)
        if result == 'find user not exists':
            self.wfile.write(result.encode())
        elif result == 'already friend':
            self.wfile.write('U{} AR'.format(tup[1]).encode())
        elif type(result) == type(tuple()):
            if tup[0] == tup [1]:
                self.wfile.write('U{} ADD'.format(tup[1]).encode())
            else:
                self.socket.sendto('U{} ADD'.format(tup[0]).encode(), eval(result[1]))

    def add_group(self, tup):
        result = Handler.mysql.add_group(tup[0], tup[1])
        print(result)
        if result == 'find group not exists':
            self.wfile.write(result.encode())
        elif result == 'already member':
            self.wfile.write('G{} AR'.format(tup[1]).encode())
        elif type(result) == type(tuple()):
            self.socket.sendto('U{} to G{} ADD'.format(tup[0], tup[1]).encode(), eval(result[1]))

    def user_refuse_add_friend(self, tup):
        result = Handler.mysql.user_refuse_add_friend(tup[0], tup[1])
        if type(result) == type(tuple()):
            print('jir')
            self.socket.sendto('U{} R U'.format(tup[0]).encode(), eval(result[1]))

    def group_refuse_add(self, tup):
        result = Handler.mysql.group_refuse_add(tup[0], tup[1])
        if type(result) == type(tuple()):
            print('goup')
            self.socket.sendto('G{} R U'.format(tup[0]).encode(), eval(result[1]))

    def user_agree_add_friend(self, tup):
        result = Handler.mysql.user_agree_add_friend(tup[0], tup[1])
        if result == 'already friend':
            self.wfile.write('U{} AR'.format(tup[1]).encode())
        elif type(result) == type(tuple()):
            if result[0] == 'send' and tup[0] != tup[1]:
                self.socket.sendto('U{} {} A U {} {} {} {} {}'.format(tup[0], result[2][1], result[2][0], result[2][2], result[2][3], result[2][4], result[2][5]).encode(), eval(result[1]))
            self.wfile.write('U{} {} RT {} {} {} {} {}'.format(tup[1], result[3][1], result[3][0], result[3][2], result[3][3], result[3][4], result[3][5]).encode())

    def group_agreed_add(self, tup):
        result = Handler.mysql.group_agreed_add(tup[0], tup[1])
        if type(result) == type(tuple()):
            if len(result) == 5:
                self.socket.sendto('G{} {} {} A U {} {} {} {} {}'.format(result[1][0], result[1][1], result[1][2], result[3][0], result[3][1], result[3][2], result[3][3], result[3][4]).encode(), eval(result[4]))
            for member in result[2]:
                self.socket.sendto('G{} {} {} C U {} {} {} {} {}'.format(result[1][0], result[1][1], result[1][2], result[3][0], result[3][1], result[3][2], result[3][3], result[3][4]).encode(), eval(member[2]))

    def user_delete_friend(self, tup):
        result = Handler.mysql.user_delete_friend(tup[0], tup[1])
        print('a', result)
        if result == 'not f':
            print(result)
            self.wfile.write('U{} R not FR'.format(tup[1]).encode())

    def group_delete(self, tup):
        result = Handler.mysql.group_delete(tup[0], tup[1])
        if result == 'not m':
            print(result)
            self.wfile.write('G{} R not MR'.format(tup[1]).encode())
        elif type(result) == type(tuple()):
            for member in result:
                self.socket.sendto('G{} kick U'.format(tup[1]).encode(), eval(member[2]))

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print('请输入addr')
    try:
        signal.signal(signal.SIGCHLD, signal.SIG_IGN)
        server = Server((sys.argv[1], int(sys.argv[2])), Handler)
    except BaseException as e:
        print('错误:', e)
        os._exit(0)
    server.serve_forever()
